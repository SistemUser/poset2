import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialization of Gemini client for robust recovery
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === "MY_GEMINI_API_KEY") {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Complete ground-truth products taxonomy matching the 20 listed types
const PRODUCTS_TAXONOMY = [
  // 1. E-TİCARET VE KARGO AMBALAJLARI
  { 
    name: "Baskılı (Logolu) Kargo Poşetleri", 
    keywords: ["baskılı kargo", "logolu kargo", "baskılı poşet"], 
    category: "kargo", 
    material: "Co-Ex Polietilen (LDPE - İki Katmanlı)", 
    thickness: "70 Mikron", 
    closure: "Permanent Bantlı (Yırtılan Sıcak Yapışkan)", 
    price: 1.45, 
    eco: 78, 
    type: "kargo",
    details: [
      "%40 oranında geri dönüştürülmüş ham maddeden imal",
      "Barkod, fatura cebi ve adres etiketine uygun mat yüzey",
      "Çift kat CO-EX yapısı ile yüksek mukavemet ve esneklik"
    ]
  },
  { 
    name: "Cepli Kargo Poşetleri", 
    keywords: ["cepli kargo", "cepli kurye", "cepli poşet"], 
    category: "kargo", 
    material: "Co-Ex Polietilen (LDPE - İki Katmanlı)", 
    thickness: "65 Mikron", 
    closure: "Permanent Bantlı & Şeffaf Fatura Cepli", 
    price: 1.35, 
    eco: 78, 
    type: "kargo",
    details: [
      "Fatura, irsaliye ve manifesto yerleşimi için ideal arka cep",
      "İçeriği gizli tutan opak siyah iç astar",
      "Su geçirmez, neme ve yırtılmaya tam dayanıklı"
    ]
  },
  { 
    name: "Standart (Baskısız) Kargo Poşetleri", 
    keywords: ["standart kargo", "baskısız kargo", "düz kargo", "gri kargo", "kargo poşeti", "kargo poşetleri"], 
    category: "kargo", 
    material: "LDPE", 
    thickness: "50 Mikron", 
    closure: "Permanent Bantlı Yapışkanlı Kapak", 
    price: 1.25, 
    eco: 75, 
    type: "kargo",
    details: [
      "Stoklu hızlı teslimat, ekonomik gönderi ambalajı",
      "Güçlü sıcak tutkal yapıştırıcı bant",
      "Standart mat gri dış renk, opak siyah iç astar"
    ]
  },
  { 
    name: "Kağıt Kargo Poşetleri", 
    keywords: ["kağıt kargo", "kraft kargo", "kağıt kurye"], 
    category: "kraft", 
    material: "Kraft Kağıt", 
    thickness: "110 gr/m²", 
    closure: "Çift Yapışkanlı Silikon Bant (Kolay İade)", 
    price: 2.80, 
    eco: 95, 
    type: "kraft",
    details: [
      "Sürdürülebilir, FSC sertifikalı biyolojik malzeme",
      "Kolay iade süreçleri için çift silikon bant seçeneği",
      "Neme karşı ekstra dirençlendirilmiş organik kraft"
    ]
  },
  { 
    name: "Fatura Cebi ve İrsaliye Zarfları", 
    keywords: ["fatura cebi", "irsaliye zarfı", "fatura poşeti", "fatura zarfı", "irsaliye zarfları"], 
    category: "bubble", 
    material: "Şeffaf PE Yapışkanlı", 
    thickness: "40 Mikron", 
    closure: "Kendinden Yapışkanlı Sırt Bölgesi", 
    price: 0.45, 
    eco: 65, 
    type: "bubble",
    details: [
      "Kolilerin ve kargo torbalarının üzerine yapıştırılan şeffaf cep",
      "Neme karşı evrakları kusursuz korur",
      "Yüksek yapışkanlık gücüne sahip akrilik veya hotmelt"
    ]
  },
  { 
    name: "Balonlu Kargo Zarfları", 
    keywords: ["balonlu kargo", "balonlu zarf", "patpatlı kargo", "korumalı zarf", "balonlu kargo zarfları"], 
    category: "bubble", 
    material: "PE Laminasyon / Hava Kabarcıklı LDPE", 
    thickness: "120 Mikron", 
    closure: "Permanent Yapışkanlı Kapak", 
    price: 2.75, 
    eco: 70, 
    type: "bubble",
    details: [
      "İç yüzeydeki patpat koruması ile hassas ürün taşıma",
      "Darbe sönümleme yeteneği ile kırılmaları engeller",
      "Elektronik parça, takı, aksesuar ve kozmetik için ideal"
    ]
  },

  // 2. PLASTİK POŞETLER
  { 
    name: "Mağaza Poşeti - El Geçme", 
    keywords: ["el geçme", "el geçmeli", "butik poşeti", "perakende poşet", "mağaza poşeti - el geçme"], 
    category: "magaza", 
    material: "LDPE Yumuşak Plastik", 
    thickness: "70 Mikron", 
    closure: "El Geçmeli Elcik Bölgesi", 
    price: 1.85, 
    eco: 70, 
    type: "magaza",
    details: [
      "Giyim ve tekstil perakendesi için şık tasarım",
      "8 renge kadar yüksek çözünürlüklü parlak boya baskı imkanı",
      "Biyo-çözünür koku ve mukavemet takviyesi opsiyonlu"
    ]
  },
  { 
    name: "Mağaza Poşeti - Takviyeli", 
    keywords: ["takviyeli", "takviyeli sap", "takviyeli poşet", "mağaza poşeti - takviyeli"], 
    category: "magaza", 
    material: "HDPE Ekstra Güçlü Plastik", 
    thickness: "85 Mikron", 
    closure: "Takviye Yamalı El Geçmeli", 
    price: 2.10, 
    eco: 70, 
    type: "magaza",
    details: [
      "El tutamağında yırtılmaları %90 engelleyen iç takviye yaması (Double-Welded)",
      "Kozmetik, ayakkabı ve tekstil firmaları için ağır yük taşıma gücü",
      "Pürüzsüz ve dökümlü mat takviyeli film kalitesi"
    ]
  },
  { 
    name: "Mağaza Poşeti - Yumuşak Saplı", 
    keywords: ["yumuşak sap", "saplı mağaza", "kulplu poşet", "şerit kulplu", "yumuşak saplı"], 
    category: "magaza", 
    material: "LDPE Premium Plastik", 
    thickness: "90 Mikron", 
    closure: "Yumuşak Şerit Sap Kaynaklı", 
    price: 2.30, 
    eco: 70, 
    type: "magaza",
    details: [
      "Lüks marka deneyimi için haricen kaynaklanmış şerit kulplar",
      "Körük detayları sayesinde geniş iç hacim sunar",
      "Göz alıcı canlı grafik baskı özellikleri"
    ]
  },
  { 
    name: "Market Poşetleri - Atlet", 
    keywords: ["atlet poşet", "hışır poşet", "market poşeti", "atlet market", "market poşetleri - atlet"], 
    category: "magaza", 
    material: "HDPE Hışır Polietilen", 
    thickness: "18 Mikron", 
    closure: "Çift Kulplu Klasik Atlet", 
    price: 0.25, 
    eco: 62, 
    type: "magaza",
    details: [
      "Yüksek mukavemetli ince hışır malzeme yapısı",
      "Ekonomik ambalaj; market, manav, fırın ve eczaneler için ideal",
      "Logolu flexo baskı uygulanabilir rulo veya dökme format"
    ]
  },
  { 
    name: "Kilitli & Fermuarlı Poşetler (Doypack vb.)", 
    keywords: ["kilitli", "fermuarlı", "doypack", "zipli", "kilitli torba", "kahve torbası"], 
    category: "gida", 
    material: "PET/ALU/PE Bariyer Laminasyon", 
    thickness: "120 Mikron", 
    closure: "Yırtma Çentikli Zip Kilit Sistemi", 
    price: 4.20, 
    eco: 60, 
    type: "gida",
    details: [
      "Oksijen, nem ve ışık bariyeri sunan çok katmanlı metalize yapı",
      "U-Clip açılış ve düzgün dik durma körüğü",
      "Gıdayla temasa %100 uygun FDA onaylı ham madde"
    ]
  },
  { 
    name: "Jelatin & OPP Poşetler", 
    keywords: ["jelatin", "opp", "baskısız jelatin", "yapışkanlı jelatin", "jelatin & opp poşetler"], 
    category: "gida", 
    material: "OPP Ultra Parlak Plastik", 
    thickness: "30 Mikron", 
    closure: "Kendinden Yapışkanlı Bant", 
    price: 0.60, 
    eco: 55, 
    type: "gida",
    details: [
      "Tekstil, çorap, gömlek paketlemede kullanılan yüksek şeffaflık",
      "Çantayı toz ve yıpranmaya karşı koruyan yapışkan silikon bantlı kapak",
      "Ürünün net bir şekilde sunulmasını sağlayan kristal cam parlaklığı"
    ]
  },
  { 
    name: "Biyobozunur (Doğada Çözünür) Poşetler", 
    keywords: ["biyobozunur", "çözünür", "doğada çözünen", "kompost", "pla poşet", "biyobozunur (doğada çözünür) poşetler"], 
    category: "magaza", 
    material: "Kompostlanabilir PLA Nişasta", 
    thickness: "45 Mikron", 
    closure: "Biyo-bozunur Taşıma Kulpu", 
    price: 2.50, 
    eco: 98, 
    type: "magaza",
    details: [
      "Mısır nişastası bazlı, endüstriyel kompostlanabilir ekolojik poşet",
      "Çevre dostu su bazlı organik logo baskı",
      "Doğada hiçbir mikro-plastik kalıntı bırakmadan %100 parçalanma"
    ]
  },

  // 3. KAĞIT VE KARTON ÇANTALAR
  { 
    name: "Kraft Çantalar", 
    keywords: ["kraft çanta", "kraft poşet", "büküm saplı", "burgu saplı", "kraft kağıt", "kraft çantalar"], 
    category: "kraft", 
    material: "FSC Sertifikalı Kraft Kağıt", 
    thickness: "90 gr/m²", 
    closure: "Kağıt Büküm Sap", 
    price: 3.40, 
    eco: 95, 
    type: "kraft",
    details: [
      "Doğal esmer veya düz beyaz şık çevreci görünüm",
      "Paket servis ve perakende tekstil butikleri için ideal burgu saplar",
      "Sıfır plastik kullanımıyla çevreyle mükemmel uyum"
    ]
  },
  { 
    name: "Lüks Karton Çantalar", 
    keywords: ["lüks karton", "karton çanta", "kuşe çanta", "bristol", "ipli çanta", "lüks karton çantalar"], 
    category: "kraft", 
    material: "Amerikan Bristol Kalın Karton", 
    thickness: "210 gr/m²", 
    closure: "Pamuk İplik Kordon Kulplu", 
    price: 4.80, 
    eco: 90, 
    type: "kraft",
    details: [
      "Premium mağazalar ve mücevher dükkanları için kalın lüks karton çanta",
      "Mat veya parlak laminasyon ve folyo gofraj baskı opsiyonu",
      "Alt tabanda ve sap kulbunda mukavemet artırıcı karton takviye lekesi"
    ]
  },
  { 
    name: "Kese Kağıtları", 
    keywords: ["kese kağıdı", "fırın poşeti", "fast food kese", "sülfit kağıt", "kese kağıtları"], 
    category: "kraft", 
    material: "Neme Dayanıklı Sülfit Kağıt", 
    thickness: "40 gr/m²", 
    closure: "Açık Ağızlı Dip Yapıştırmalı", 
    price: 0.85, 
    eco: 95, 
    type: "kraft",
    details: [
      "Fırın ürünleri, fast food, unlu mamul ve kuru yemiş ambalajı",
      "Sıcak yağlı veya şuruplu yiyeceklere dayanıklı iç kaplama polietilen",
      "Hafif ve son derece ekonomik gıda ambalajı çözümü"
    ]
  },

  // 4. BEZ VE TELA ÇANTALAR
  { 
    name: "Nonwoven (Tela) Çantalar", 
    keywords: ["tela çanta", "nonwoven", "bez çanta tela", "elyaf çanta", "tela çantalar"], 
    category: "bubble", 
    material: "Tela Elyaf (Nonwoven)", 
    thickness: "80 gr/m²", 
    closure: "Ultrasonik Dikişli Taşıma Sapı", 
    price: 5.50, 
    eco: 90, 
    type: "bubble",
    details: [
      "Defalarca kullanılabilen ekolojik fuar ve mağaza bez çantası",
      "Ultrasonik dikiş tırnaklarıyla ağır yük dayanımı",
      "Çevre dostu, suya dayanıklı ve şık kurumsal ambalaj ürünü"
    ]
  },
  { 
    name: "Ham Bez (Pamuk) Çantalar", 
    keywords: ["ham bez", "pamuk çanta", "kumaş çanta", "promosyon bez", "ham bez (pamuk) çantalar"], 
    category: "bubble", 
    material: "%100 Naturel Ham Pamuk", 
    thickness: "140gr Kumaş", 
    closure: "Omuz Askılı Dikim Kulplu", 
    price: 12.00, 
    eco: 95, 
    type: "bubble",
    details: [
      "Sokak modasına uyumlu promosyon ve marka elçisi bez çanta",
      "Doğal pamuk ipliğinden mukavemetli dikişli yapı",
      "Çamaşır makinesinde yıkanabilir uzun ömürlü kullanım imkanı"
    ]
  },

  // 5. KORUYUCU VE ENDÜSTRİYEL AMBALAJ
  { 
    name: "Balonlu Patpat Naylonlar", 
    keywords: ["balonlu patpat", "patpat naylon", "patpat rulo", "balonlu ambalaj", "patpat naylonlar"], 
    category: "bubble", 
    material: "LDPE Balonlu Naylon (Rulo)", 
    thickness: "120 Mikron", 
    closure: "Rulo Ambalaj Malzemesi", 
    price: 3.50, 
    eco: 65, 
    type: "bubble",
    details: [
      "Kırılgan lüks eşya, seramik ve mobilyaları sarmada üstün teknoloji",
      "Tozdan, nemden ve sürtünme çiziklerinden tam koruma saglar",
      "Hava yastıklı kabarcık yapısı sayesinde sarsıntı emici yapı"
    ]
  },
  { 
    name: "Şrink Filmler (P.E, POF, PVC)", 
    keywords: ["şrink", "shrink", "pof film", "pvc film", "paketleme filmi", "şrink filmler"], 
    category: "bubble", 
    material: "Poliolefin (POF) Isıyla Daralan", 
    thickness: "15 Mikron", 
    closure: "Rulo Isıl Yapıştırma Şeridi", 
    price: 2.10, 
    eco: 60, 
    type: "bubble",
    details: [
      "Ürün grubunu ısı tünelinde gererek tek bir paket haline getiren film",
      "Toz ve neme karşı tam korumalı endüstriyel ambalaj katmanı",
      "Kristal şeffaflık ile paketlenen ürünleri şık bir şekilde sunar"
    ]
  }
];

// Support Turkish input and create realistic default quotes using the exact taxonomy match
function getRuleBasedFallback(prompt: string) {
  const norm = prompt.toLowerCase();
  
  // Try to find the exact matched product from the complete taxonomy list
  let matched = PRODUCTS_TAXONOMY.find(p => {
    return p.keywords.some(kw => norm.includes(kw)) || norm.includes(p.name.toLowerCase());
  });

  // Safe fallback if no exact product matches
  if (!matched) {
    if (norm.includes("kraft") || norm.includes("kağıt") || norm.includes("çanta") || norm.includes("karton")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Kraft Çantalar");
    } else if (norm.includes("gıda") || norm.includes("kahve") || norm.includes("doypack") || norm.includes("kilit")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Kilitli & Fermuarlı Poşetler (Doypack vb.)");
    } else if (norm.includes("patpat") || norm.includes("balonlu")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Balonlu Patpat Naylonlar");
    } else if (norm.includes("şrink") || norm.includes("shrink")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Şrink Filmler (P.E, POF, PVC)");
    } else if (norm.includes("tela") || norm.includes("nonwoven")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Nonwoven (Tela) Çantalar");
    } else if (norm.includes("bez") || norm.includes("pamuk")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Ham Bez (Pamuk) Çantalar");
    } else if (norm.includes("kargo") || norm.includes("zarf")) {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Standart (Baskısız) Kargo Poşetleri");
    } else {
      matched = PRODUCTS_TAXONOMY.find(p => p.name === "Mağaza Poşeti - El Geçme");
    }
  }

  const p = matched!;
  const dimensions = norm.match(/(\d+)\s*[x*]\s*(\d+)/) 
    ? `${norm.match(/(\d+)\s*[x*]\s*(\d+)/)![1]}x${norm.match(/(\d+)\s*[x*]\s*(\d+)/)![2]} cm`
    : (p.type === "kraft" ? "26x35x9 cm" : (p.type === "kargo" ? "30x40 cm" : "35x45 cm"));

  const quantityMatch = norm.match(/(\d+)\s*(bin|adet|pcs)/);
  const qty = quantityMatch ? parseInt(quantityMatch[1]) * (norm.includes("bin") ? 1000 : 1) : 10000;
  
  const formattedPrice = `₺${p.price.toFixed(2)}`;
  const formattedTotal = `₺${Math.round(qty * p.price).toLocaleString()}`;
  
  return {
    assistantText: `Seçmiş olduğunuz **${p.name}** ürünü için teknik spesifikasyon şartnamesini ve kurumsal ambalaj teklif şablonunuzu oluşturduk. ${p.material} yapısı ve yüksek dirençli yapısıyla mukavemeti en üst düzeyde tutmaktadır. Markanızın değerini artıracak kurumsal çözümlerimizi özellikleri ile birlikte inceleyebilirsiniz.`,
    spec: {
      dimensions,
      material: p.material,
      thickness: p.thickness,
      closure: p.closure,
      color: norm.includes("beyaz") ? "Beyaz Renkli Zemin" : (norm.includes("siyah") ? "Siyah Renkli Zemin" : "Standart Renkli Zemin"),
      leadTime: "10-12 İş Günü",
      moq: `${qty.toLocaleString()} Adet`,
      unitPrice: formattedPrice,
      totalPrice: formattedTotal,
      imageType: p.category as any,
      customDetails: p.details,
      ecoScore: p.eco
    }
  };
}

// API endpoint to process prompt via Gemini Or fallback
app.post("/api/quote", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt || typeof prompt !== "string") {
    return res.status(400).json({ error: "Lütfen bir prompt belirtin." });
  }

  // Define dynamic mapping generator based on extracted structured parameters
  const generateDynamicPayload = (extracted: {
    urun_kategorisi: string;
    adet_miktari: number;
    baski_durumu: "Baskılı" | "Baskısız";
    baski_detayi: {
      renk_sayisi: number;
      baski_tarafi: "Tek Yön" | "Çift Yön";
    }
  }) => {
    const rawCategory = extracted.urun_kategorisi || "El Geçmeli Mağaza Poşeti";
    const baskiDurumu = extracted.baski_durumu || "Baskılı";
    const baskiDetayi = extracted.baski_detayi || { renk_sayisi: 2, baski_tarafi: "Tek Yön" };

    const norm = (rawCategory + " " + prompt).toLowerCase();
    
    // Find the closest product matched in our core taxonomy
    let matched = PRODUCTS_TAXONOMY.find(p => {
      return p.keywords.some(kw => norm.includes(kw)) || norm.includes(p.name.toLowerCase());
    });

    if (!matched) {
      if (norm.includes("kraft") || norm.includes("kağıt") || norm.includes("çanta") || norm.includes("karton")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Kraft Çantalar");
      } else if (norm.includes("gıda") || norm.includes("kahve") || norm.includes("doypack") || norm.includes("kilit")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Kilitli & Fermuarlı Poşetler (Doypack vb.)");
      } else if (norm.includes("patpat") || norm.includes("balonlu")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Balonlu Patpat Naylonlar");
      } else if (norm.includes("şrink") || norm.includes("shrink")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Şrink Filmler (P.E, POF, PVC)");
      } else if (norm.includes("tela") || norm.includes("nonwoven")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Nonwoven (Tela) Çantalar");
      } else if (norm.includes("bez") || norm.includes("pamuk")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Ham Bez (Pamuk) Çantalar");
      } else if (norm.includes("kargo") || norm.includes("zarf")) {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Standart (Baskısız) Kargo Poşetleri");
      } else {
        matched = PRODUCTS_TAXONOMY.find(p => p.name === "Mağaza Poşeti - El Geçme");
      }
    }

    const p = matched!;
    
    const isKgProduct = p.name.toLowerCase().includes("şrink") || 
                        p.name.toLowerCase().includes("shrink") || 
                        p.name.toLowerCase().includes("patpat") || 
                        p.name.toLowerCase().includes("balonlu") ||
                        p.name.toLowerCase().includes("rulo") ||
                        norm.includes("kg") || 
                        norm.includes("rulo") || 
                        norm.includes("film");

    let adetMiktari = extracted.adet_miktari || (isKgProduct ? 500 : 10000);
    // If the quantity was parsed as default but user prompted kg, it might be 10000 which is huge for kg, so scale down to sensible 500 if unstated
    if (isKgProduct && adetMiktari === 10000 && !prompt.includes("10000") && !prompt.includes("10.000")) {
      adetMiktari = 500;
    }

    let specType = p.category;
    let material = p.material;
    let thickness = p.thickness;
    let closure = p.closure;
    let color = "Parlak Beyaz / Özel Pantone";
    let leadTime = "12-14 İş Günü";
    let priceUnit = p.price;
    let ecoScore = p.eco;
    let customDetails = p.details;
    let dimensions = p.type === "kraft" ? "26x35x9 cm" : (p.type === "kargo" ? "30x40 cm" : "35x45 cm");

    // Extract dimensions from user prompt if specified
    const dimMatch = prompt.match(/(\d+)\s*[x*]\s*(\d+)/);
    if (dimMatch) {
      dimensions = `${dimMatch[1]}x${dimMatch[2]} cm`;
    }

    // Apply price multipliers for printed configurations or scale economies
    if (baskiDurumu === "Baskılı") {
      const colors = baskiDetayi.renk_sayisi || 2;
      const premiumTaraf = baskiDetayi.baski_tarafi === "Çift Yön" ? 1.25 : 1.0;
      priceUnit = priceUnit * (1 + (colors - 1) * 0.08) * premiumTaraf;
    } else {
      // Unprinted is 15% cheaper on face value but lacks marketing utility
      priceUnit = priceUnit * 0.85;
    }

    const unitLabel = isKgProduct ? "Kg" : "Adet";

    // Ensure price decimals look appropriate
    const formattedPrice = `₺${priceUnit.toFixed(2)}`;
    const formattedTotal = `₺${Math.round(adetMiktari * priceUnit).toLocaleString()}`;

    // Generate expert interactive text addressing brand logos, color triggers and promotional up-selling
    let assistantText = "";
    if (baskiDurumu === "Baskılı") {
      assistantText = `
**Tebrikler! Marka logolu ve prestijli bir kurumsal ambalaj tasarımı seçtiniz.** 

Yapay zeka asistanı analizimiz sonucunda, firmanızın kurumsal değerini sokağa taşıyacak **${p.name}** spesifikasyon şartnamesini hazırladım. Detayları yan tarafta yer alan teknik panelde inceleyebilirsiniz. 

Sokaklarda markanızın ücretsiz reklamını yapacak **${baskiDetayi.renk_sayisi} Renk ${baskiDetayi.baski_tarafi}** baskılı üretimimiz için şu bilgileri paylaşabilir misiniz?
1. **Marka logonuz hazır mı?** Vektörel formatta (.PDF, .AI, .CDR, .EPS) logonuzu bize iletebilir misiniz? Kaç renkli bir baskı planlıyorsunuz?
2. Tasarım ekibimizin size tamamen **ücretsiz** hazırlayacağı **3D ambalaj ön izleme mock-up** çalışmasıyla logo yerleşimini görmek ister misiniz?

Belirttiğiniz **${adetMiktari.toLocaleString()} ${unitLabel}** sipariş hacmi için tüm üretim hattı optimize edilmiştir.
      `.trim();
    } else {
      // Up-sell dynamic content
      assistantText = `
Talebiniz doğrultusunda **${adetMiktari.toLocaleString()} ${unitLabel}** baskısız (düz) **${p.name}** teknik şartnamesini derledim. Detaylara yan taraftan göz atabilirsiniz.

**💡 Ambalaj & Marka Gücü Hakkında Önemli Bir Hatırlatma:**
Düz (baskısız) ambalajlar ilk aşamada bütçeye uygun görünse de, müşterilerinizin ürününüzü taşırken yapacağı reklamın değeri paha biçilemezdir. **Logo baskılı özel tasarım ambalajlar, firmanıza kurumsal bir imaj kazandırır ve marka bilinirliğini ücretsiz olarak %85 oranında artırır!**

Gelin markanıza elit bir değer katmak adına küçük bir dokunuş yapalım:
- Markanızın logosunu bizimle paylaşın, grafik ekibimiz size **tamamen taahhütsüz ve ücretsiz olarak 3D logolu ambalaj görselleştirmesi** hazırlasın.
- Baskılı seçeneğin birim fiyattaki ufak farkını kıyaslamak ve markanızın kurumsal prestijini katlamak için tasarladığınız **renk sayısını** bize iletmeniz yeterli!
      `.trim();
    }

    const renkSayisiString = baskiDetayi.renk_sayisi === 1 ? "1 Renk" :
                            baskiDetayi.renk_sayisi === 2 ? "2 Renk" :
                            baskiDetayi.renk_sayisi === 3 ? "3 Renk" :
                            baskiDetayi.renk_sayisi === 4 ? "4 Renk (CMYK)" : "5+ Renk / Özel Renk";

    return {
      assistantText,
      spec: {
        dimensions,
        material,
        thickness,
        closure,
        color,
        leadTime,
        moq: `${adetMiktari.toLocaleString()} ${unitLabel}`,
        unitPrice: formattedPrice,
        totalPrice: formattedTotal,
        imageType: specType,
        customDetails,
        ecoScore,
        baskiDurumu: (baskiDurumu === "Baskısız" ? "Baskısız" : "Baskılı"),
        renkSayisi: renkSayisiString
      }
    };
  };

  const ai = getGeminiClient();
  if (!ai) {
    // If no client configured, parse prompt directly with default parameters complying with rules
    console.log("No Gemini API key detected in secrets. Emulating strict response schema...");
    const norm = prompt.toLowerCase();
    
    // Default to printed ("Baskılı") unless user explicitly states unprinted ("baskısız", "baskı istemiyorum")
    const isExplicitUnprinted = norm.includes("baskısız") || norm.includes("baskı istemiyorum") || norm.includes("baskı olmasın");
    const baskiDurumu = isExplicitUnprinted ? "Baskısız" : "Baskılı";
    
    let urunKategorisi = "El Geçmeli Mağaza Poşeti";
    if (norm.includes("kargo")) urunKategorisi = "Kargo Poşeti";
    else if (norm.includes("kraft") || norm.includes("kağıt")) urunKategorisi = "Kraft Taşıma Çantası";
    else if (norm.includes("gıda") || norm.includes("kahve") || norm.includes("doypack")) urunKategorisi = "Doypack Kilitli Gıda Ambalajı";
    else if (norm.includes("balonlu") || norm.includes("bubble") || norm.includes("patpat")) urunKategorisi = "Balonlu Patpat Ambalaj";

    const extracted = {
      urun_kategorisi: urunKategorisi,
      adet_miktari: norm.includes("kraft") ? 5000 : 10000,
      baski_durumu: baskiDurumu as "Baskılı" | "Baskısız",
      baski_detayi: {
        renk_sayisi: isExplicitUnprinted ? 0 : 2,
        baski_tarafi: "Tek Yön" as "Tek Yön" | "Çift Yön"
      }
    };

    const payload = generateDynamicPayload(extracted);
    return res.json({
      ...payload,
      structuredAnalysis: extracted
    });
  }

  try {
    const promptInstructions = `
      You are the specialized "poset.com Industrial Design & Commercial Ambalaj AI".
      The user wants to customize a packaging solution (kargo poşeti, kraft çanta, doypack gıda ambalajı, balonlu ambalaj or mağaza poşeti).
      Analyze their raw natural language prompt: "${prompt}"

      CRITICAL TİCARİ ODAK (COMMERCIAL FOCUS) Guidelines:
      1. Default to Printed (Baskılı): If the user gives a plain/vague request like "Kargo poşeti istiyorum" or "Mağaza poşeti lazım" WITHOUT specifying printed or unprinted, you MUST assume "baski_durumu" is "Baskılı".
      2. If they explicitly request unprinted (e.g. "baskısız poşet", "baskısı olmasın"), set "baski_durumu" to "Baskısız" and color_count to 0.
      3. For printed bags, set "renk_sayisi" to at least 1 or 2 by default unless specified. "baski_tarafi" defaults to "Tek Yön" unless they specify double-sided ("çift yön").

      Output MUST strictly follow the requested JSON schema constraints.
    `;

    let response;
    try {
      response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptInstructions,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              urun_kategorisi: { 
                type: Type.STRING,
                description: "E-ticaret Kargo Poşeti, FSC Sertifikalı Kraft Çanta, Doypack Gıda Ambalajı, El Geçmeli Mağaza Poşeti veya Balonlu Patpat Ambalaj."
              },
              adet_miktari: { 
                type: Type.INTEGER,
                description: "Talep edilen adet miktarı. Kullanıcı belirtmediyse sektörel MOQ değerini varsayılan yap: Kraft için 5000, Plastikler için 10000."
              },
              baski_durumu: { 
                type: Type.STRING, 
                enum: ["Baskılı", "Baskısız"],
                description: "Kullanıcı doğal dil girerken baskısız olduğunu doğrudan belirtmediyse varsayılan olarak kesinlikle 'Baskılı' yap."
              },
              baski_detayi: {
                type: Type.OBJECT,
                properties: {
                  renk_sayisi: { 
                    type: Type.INTEGER,
                    description: "Baskı renk sayısı. Eğer baskı durumu Baskılı ise ve belirtilmemişse varsayılan olarak en az 1 or 2 yap. Baskısız ise 0 yap."
                  },
                  baski_tarafi: { 
                    type: Type.STRING, 
                    enum: ["Tek Yön", "Çift Yön"],
                    description: "Baskı uygulanacak taraf yönü. Belirtilmemişse varsayılan olarak 'Tek Yön' seç."
                  }
                },
                required: ["renk_sayisi", "baski_tarafi"]
              }
            },
            required: ["urun_kategorisi", "adet_miktari", "baski_durumu", "baski_detayi"]
          }
        }
      });
    } catch (primaryModelError) {
      console.log("Primary Gemini model busy, attempting secondary fallback model...");
      response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: promptInstructions,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              urun_kategorisi: { 
                type: Type.STRING,
                description: "E-ticaret Kargo Poşeti, FSC Sertifikalı Kraft Çanta, Doypack Gıda Ambalajı, El Geçmeli Mağaza Poşeti veya Balonlu Patpat Ambalaj."
              },
              adet_miktari: { 
                type: Type.INTEGER,
                description: "Talep edilen adet miktarı. Kullanıcı belirtmediyse sektörel MOQ değerini varsayılan yap: Kraft için 5000, Plastikler için 10000."
              },
              baski_durumu: { 
                type: Type.STRING, 
                enum: ["Baskılı", "Baskısız"],
                description: "Kullanıcı doğal dil girerken baskısız olduğunu doğrudan belirtmediyse varsayılan olarak kesinlikle 'Baskılı' yap."
              },
              baski_detayi: {
                type: Type.OBJECT,
                properties: {
                  renk_sayisi: { 
                    type: Type.INTEGER,
                    description: "Baskı renk sayısı. Eğer baskı durumu Baskılı ise ve belirtilmemişse varsayılan olarak en az 1 or 2 yap. Baskısız ise 0 yap."
                  },
                  baski_tarafi: { 
                    type: Type.STRING, 
                    enum: ["Tek Yön", "Çift Yön"],
                    description: "Baskı uygulanacak taraf yönü. Belirtilmemişse varsayılan olarak 'Tek Yön' seç."
                  }
                },
                required: ["renk_sayisi", "baski_tarafi"]
              }
            },
            required: ["urun_kategorisi", "adet_miktari", "baski_durumu", "baski_detayi"]
          }
        }
      });
    }

    let extracted;
    try {
      const respText = response?.text;
      if (respText && typeof respText === "string" && respText.trim() !== "") {
        const cleanedText = respText.replace(/```json/gi, "").replace(/```/g, "").trim();
        if (cleanedText === "undefined" || !cleanedText.startsWith("{")) {
          console.warn("Gemini response is not valid JSON format:", cleanedText);
          extracted = {};
        } else {
          try {
            extracted = JSON.parse(cleanedText);
          } catch (pe) {
            console.warn("JSON.parse failed on cleanedText:", cleanedText, pe);
            extracted = {};
          }
        }
      } else {
        extracted = {};
      }
    } catch (pe) {
      console.warn("Gemini response processing failed:", pe);
      extracted = {};
    }
    
    // Generate full UI model spec and text based on the strictly validated Gemini structured extraction
    const payload = generateDynamicPayload(extracted);

    return res.json({
      ...payload,
      structuredAnalysis: extracted
    });

  } catch (error) {
    console.log("Gemini model capacity limits or error encountered, activation of clean rules-based generator");
    // Silent failover to premium secure backup with commercial rules emulated
    const norm = prompt.toLowerCase();
    const isExplicitUnprinted = norm.includes("baskısız") || norm.includes("baskı istemiyorum");
    const extractedFallback = {
      urun_kategorisi: norm.includes("kargo") ? "Kargo Poşeti" : (norm.includes("kraft") ? "Kraft Taşıma Çantası" : "El Geçmeli Mağaza Poşeti"),
      adet_miktari: norm.includes("kraft") ? 5000 : 10000,
      baski_durumu: (isExplicitUnprinted ? "Baskısız" : "Baskılı") as "Baskılı" | "Baskısız",
      baski_detayi: {
        renk_sayisi: isExplicitUnprinted ? 0 : 2,
        baski_tarafi: "Tek Yön" as "Tek Yön" | "Çift Yön"
      }
    };
    const payload = generateDynamicPayload(extractedFallback);
    return res.json({
      ...payload,
      structuredAnalysis: extractedFallback
    });
  }
});

// Vite server configuration helper
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware integrated successfully.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving compiled production assets from ./dist");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Poset Industrial full-stack server running on port ${PORT}`);
  });
}

startServer();
