export interface Product {
  id: string;
  name: string;
  category: string; // "kargo" | "magaza" | "kraft" | "gıda"
  material: string;
  thickness: string;
  pricePerUnit: number;
  currency: string;
  moq: number;
  imageUrl: string;
  tags: string[];
  capacity: string;
  description: string;
}

export type ImageType = "kargo" | "magaza" | "kraft" | "gida" | "bubble";

export interface QuoteSpec {
  dimensions: string;
  material: string;
  thickness: string;
  closure: string;
  color: string;
  leadTime: string;
  moq: string;
  unitPrice: string;
  totalPrice: string;
  imageType: ImageType;
  customDetails: string[];
  ecoScore?: number; // 1-100 rating
  baskiDurumu?: "Baskılı" | "Baskısız";
  renkSayisi?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  quoteSpec?: QuoteSpec;
}

export interface FilterState {
  searchQuery: string;
  categories: string[];
  materials: string[];
  minThickness: number;
  maxThickness: number;
  sortBy: "popular" | "price_asc" | "price_desc";
}
