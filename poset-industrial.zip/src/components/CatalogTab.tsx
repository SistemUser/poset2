import React, { useState, useMemo } from "react";
import { Filter, Search, ChevronDown, Check, FolderOpen, Heart, ShoppingBag, FileSpreadsheet, Sparkles } from "lucide-react";
import { Product } from "../types";
import { IMAGES } from "../constants";
import { TAXONOMY_PRODUCTS, CATEGORIES, TaxonomyProduct } from "../productsData";
import Footer from "./Footer";

interface CatalogTabProps {
  onAddToQuoteList: (product: Product) => void;
  onCustomizeWithAI: (productName: string) => void;
  setTab: (tab: "home" | "catalog" | "assistant") => void;
}

export default function CatalogTab({ onAddToQuoteList, onCustomizeWithAI, setTab }: CatalogTabProps) {
  // Real layout parameters for filtering matching Image 3 sidebar:
  const [activeKullanim, setActiveKullanim] = useState<string[]>(["kargo_eticaret"]); // E-commerce and Cargo checked by default
  const [activeMalzeme, setActiveMalzeme] = useState<string[]>([]);
  const [activeBaski, setActiveBaski] = useState<string>("");
  const [minMikron, setMinMikron] = useState("");
  const [maxMikron, setMaxMikron] = useState("");
  const [addedProductId, setAddedProductId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState("Önerilenler");

  const toggleBaski = (key: string) => {
    setActiveBaski(prev => (prev === key ? "" : key));
  };

  // Helper arrays for filters
  const kullanimFilterNodes = CATEGORIES;

  const malzemeFilterNodes = [
    { key: "pe", label: "Polietilen (PE) / Plastik" },
    { key: "kraft", label: "Kağıt / Kraft" },
    { key: "bez", label: "Bez / Tela" },
    { key: "endustriyel", label: "Endüstriyel & Koruyucu" }
  ];

  const toggleKullanim = (key: string) => {
    setActiveKullanim(prev => 
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const toggleMalzeme = (key: string) => {
    setActiveMalzeme(prev => 
      prev.includes(key) ? prev.filter(m => m !== key) : [...prev, key]
    );
  };

  const clearAllFilters = () => {
    setActiveKullanim([]);
    setActiveMalzeme([]);
    setActiveBaski("");
    setMinMikron("");
    setMaxMikron("");
  };

  // Run dynamic filter algorithm
  const filteredProducts = useMemo(() => {
    let result = TAXONOMY_PRODUCTS.filter(p => {
      // Kullanim category filter match
      if (activeKullanim.length > 0) {
        if (!activeKullanim.includes(p.categoryKey)) return false;
      }
      // Malzeme filter match
      if (activeMalzeme.length > 0) {
        const matchesMalzeme = activeMalzeme.some(m => {
          const mat = p.malzeme.toLowerCase();
          if (m === "pe" && (mat.includes("pe") || mat.includes("polietilen") || mat.includes("plastik") || mat.includes("opp") || mat.includes("pla"))) return true;
          if (m === "kraft" && (mat.includes("kraft") || mat.includes("kağıt") || mat.includes("karton") || mat.includes("sülfit") || mat.includes("bristol"))) return true;
          if (m === "bez" && (mat.includes("tela") || mat.includes("bez") || mat.includes("pamuk") || mat.includes("nonwoven"))) return true;
          if (m === "endustriyel" && (mat.includes("patpat") || mat.includes("şrink") || mat.includes("film") || mat.includes("laminasyon"))) return true;
          return false;
        });
        if (!matchesMalzeme) return false;
      }
      // Baskı Türü filter match
      if (activeBaski) {
        if (activeBaski === "baskili" && p.baski === "Baskısız") return false;
        if (activeBaski === "baskisiz" && p.baski !== "Baskısız") return false;
      }
      return true;
    });

    // Handle sort
    if (sortBy === "artan") {
      result = [...result].sort((a, b) => {
        const priceA = a.priceText === "Fiyat Alınız" ? 99999 : parseFloat(a.priceText.replace(/[^0-9.]/g, ""));
        const priceB = b.priceText === "Fiyat Alınız" ? 99999 : parseFloat(b.priceText.replace(/[^0-9.]/g, ""));
        return priceA - priceB;
      });
    } else if (sortBy === "azalan") {
      result = [...result].sort((a, b) => {
        const priceA = a.priceText === "Fiyat Alınız" ? 0 : parseFloat(a.priceText.replace(/[^0-9.]/g, ""));
        const priceB = b.priceText === "Fiyat Alınız" ? 0 : parseFloat(b.priceText.replace(/[^0-9.]/g, ""));
        return priceB - priceA;
      });
    }

    return result;
  }, [activeKullanim, activeMalzeme, activeBaski, sortBy]);

  const handleAddAction = (prod: TaxonomyProduct) => {
    // Adapter conversion to general shape
    const item: Product = {
      id: prod.id,
      name: prod.name,
      category: prod.categoryKey,
      material: prod.malzeme,
      thickness: prod.specValue,
      pricePerUnit: prod.priceText === "Fiyat Alınız" ? 0 : parseFloat(prod.priceText.replace(/[^0-9.]/g, "")),
      currency: "₺",
      moq: 10000,
      imageUrl: prod.imgUrl,
      tags: [prod.baski],
      capacity: "Standart",
      description: prod.desc
    };

    onAddToQuoteList(item);
    setAddedProductId(prod.id);
    setTimeout(() => {
      setAddedProductId(null);
    }, 1800);
  };

  return (
    <div className="bg-[#fcfdfd] min-h-screen pt-10">
      <div className="max-w-7xl mx-auto px-6 space-y-10">

        {/* Header Title Information matches mockup perfectly */}
        <div className="space-y-2">
          <h1 className="text-3xl font-black text-[#0f172a] tracking-tight">
            Ürün Kataloğu
          </h1>
          <p className="text-xs text-slate-500 max-w-2xl leading-relaxed font-medium">
            İhtiyacınıza uygun endüstriyel ve ticari ambalaj çözümlerini filtreleyin.
          </p>
        </div>

        {/* Two-Column split workspace block */}
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Sidebar Filters Section (Exactly match design of Image 3 Left Panel) */}
          <aside className="lg:col-span-3 bg-white border border-slate-200/70 p-6 rounded-3xl shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="font-extrabold text-sm text-[#0f172a] uppercase tracking-wider font-sans">
                Filtreler
              </span>
              <button 
                onClick={clearAllFilters}
                className="text-xs font-bold text-[#e11d48] hover:text-red-700 active:scale-95 transition-all cursor-pointer"
              >
                Temizle
              </button>
            </div>

            {/* Group 1: KULLANIM ALANI with real checkboxes and counts */}
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 font-mono">
                Kullanım Alanı
              </h4>
              <div className="space-y-2.5">
                {kullanimFilterNodes.map(node => {
                  const isChecked = activeKullanim.includes(node.key);
                  return (
                    <div 
                      key={node.key}
                      onClick={() => toggleKullanim(node.key)}
                      className="flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center space-x-2.5 text-slate-600 text-sm font-semibold">
                        <div className={`w-4 h-4 rounded border transition-all flex items-center justify-center ${
                          isChecked ? "bg-[#0b1c3f] border-[#0b1c3f]" : "border-slate-300 bg-white group-hover:border-slate-400"
                        }`}>
                          {isChecked && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <span className={isChecked ? "text-[#0b1c3f] font-bold" : "text-slate-600 font-medium"}>
                          {node.label}
                        </span>
                      </div>
                      
                      <span className="text-[10px] font-mono font-black text-slate-400 bg-slate-100 px-2.5 py-0.5 rounded-full">
                        {node.count}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Group 2: MALZEME CİNSİ */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 font-mono">
                Malzeme Cinsi
              </h4>
              <div className="space-y-2.5">
                {malzemeFilterNodes.map(node => {
                  const isChecked = activeMalzeme.includes(node.key);
                  return (
                    <div 
                      key={node.key}
                      onClick={() => toggleMalzeme(node.key)}
                      className="flex items-center space-x-2.5 cursor-pointer text-slate-600 text-sm font-semibold group"
                    >
                      <div className={`w-4 h-4 rounded border transition-all flex items-center justify-center ${
                        isChecked ? "bg-[#0b1c3f] border-[#0b1c3f]" : "border-slate-300 bg-white group-hover:border-slate-400"
                      }`}>
                        {isChecked && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                      </div>
                      <span className={isChecked ? "text-[#0b1c3f] font-bold" : "text-slate-600 font-medium"}>
                        {node.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Group 2.2: BASKI TÜRÜ */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 font-mono">
                Baskı Türü
              </h4>
              <div className="space-y-2.5">
                {[
                  { key: "baskili", label: "Baskılı (Kurumsal Logolu)" },
                  { key: "baskisiz", label: "Baskısız (Düz / Standart)" }
                ].map(node => {
                  const isChecked = activeBaski === node.key;
                  return (
                    <label 
                      key={node.key}
                      className="flex items-center space-x-2.5 cursor-pointer text-slate-600 text-sm font-semibold group select-none"
                    >
                      <input
                        type="radio"
                        name="baski_turu"
                        checked={isChecked}
                        onChange={() => toggleBaski(node.key)}
                        className="sr-only"
                      />
                      <div className={`w-4 h-4 rounded-full border transition-all flex items-center justify-center ${
                        isChecked ? "bg-[#0b1c3f] border-[#0b1c3f]" : "border-slate-300 bg-white group-hover:border-slate-400"
                      }`}>
                        {isChecked && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                      </div>
                      <span className={isChecked ? "text-[#0b1c3f] font-bold" : "text-slate-600 font-medium"}>
                        {node.label}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Group 3: KALINLIK (MİKRON) */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 font-mono">
                Kalınlık (Mikron)
              </h4>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <input
                    type="number"
                    placeholder="Min"
                    value={minMikron}
                    onChange={(e) => setMinMikron(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-semibold px-3 py-2 rounded-xl focus:bg-white focus:outline-none focus:border-[#0b1c3f] text-slate-700"
                  />
                </div>
                <div>
                  <input
                    type="number"
                    placeholder="Max"
                    value={maxMikron}
                    onChange={(e) => setMaxMikron(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-semibold px-3 py-2 rounded-xl focus:bg-white focus:outline-none focus:border-[#0b1c3f] text-slate-700"
                  />
                </div>
              </div>
            </div>

          </aside>

          {/* Right Area: Grid items display */}
          <main className="lg:col-span-9 space-y-6">
            
            {/* Controls Bar matches Image 3 details perfectly */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <span className="text-xs font-bold text-slate-500 font-sans">
                Toplam <span className="font-extrabold text-[#0f172a]">124</span> Ürün Listeleniyor.
              </span>

              {/* Sorting tools dropdown alignment */}
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-400">Sırala:</span>
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="appearance-none bg-white border border-slate-200 pr-9 pl-3.5 py-2 text-xs font-bold text-slate-700 rounded-xl focus:outline-none focus:border-[#0b1c3f] cursor-pointer"
                  >
                    <option value="Önerilenler">Önerilenler</option>
                    <option value="artan">Fiyat: Artan</option>
                    <option value="azalan">Fiyat: Azalan</option>
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Dynamic Grid layout with Image 3 exact card layouts */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6" id="catalog-main-grid">
              {filteredProducts.map((prod) => (
                <div 
                  key={prod.id}
                  className="bg-white rounded-3xl border border-slate-200/70 overflow-hidden shadow-xs hover:shadow-xl hover:border-slate-300 transition-all duration-300 flex flex-col justify-between group"
                >
                  
                  {/* Card Section Header */}
                  <div>
                    {/* Centered Image wrap */}
                    <div className="h-48 bg-slate-50 relative overflow-hidden flex items-center justify-center">
                      <img 
                        src={prod.imgUrl} 
                        alt={prod.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Floating Badges in top-right area */}
                      <div className="absolute top-3.5 right-3.5 flex flex-wrap gap-1.5 justify-end">
                        {prod.badges.map((b: string, i: number) => (
                          <span 
                            key={i}
                            className={`text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider font-mono shadow-xs border ${
                              b === "Çok Satan" 
                                ? "bg-rose-50 text-rose-600 border-rose-100" 
                                : b === "Üretime Hazır" 
                                  ? "bg-amber-50 text-amber-600 border-amber-100" 
                                  : "bg-stone-50 text-slate-600 border-slate-200"
                            }`}
                          >
                            {b}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Card Content parameters & titles */}
                    <div className="p-5.5 space-y-4">
                      <div className="space-y-1">
                        <h3 className="font-black text-[15px] text-[#0f172a] group-hover:text-[#2563eb] transition-all">
                          {prod.name}
                        </h3>
                        <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                          {prod.desc}
                        </p>
                      </div>

                      {/* Overlaid Technical Specification Card Table (As shown in screenshot) */}
                      <div className="bg-slate-50/75 border border-slate-100 rounded-2xl p-3.5 text-xs space-y-1.5 font-sans">
                        <div className="flex justify-between items-center text-[11px]">
                          <span className="text-slate-400 font-semibold uppercase tracking-wider font-mono text-[9px]">Malzeme</span>
                          <span className="font-extrabold text-slate-700">{prod.malzeme}</span>
                        </div>
                        <div className="flex justify-between items-center text-[11px]">
                          <span className="text-slate-400 font-semibold uppercase tracking-wider font-mono text-[9px]">
                            {prod.specLabel || "Kalınlık"}
                          </span>
                          <span className="font-extrabold text-slate-700">{prod.specValue}</span>
                        </div>
                        <div className="flex justify-between items-center text-[11px]">
                          <span className="text-slate-400 font-semibold uppercase tracking-wider font-mono text-[9px]">Baskı</span>
                          <span className="font-extrabold text-slate-700">{prod.baski}</span>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Card Actions Footer - Unit Price & dynamic buttons */}
                  <div className="px-5.5 pb-5.5 pt-2 border-t border-slate-50 space-y-4">
                    
                    {/* Unit pricing detail match */}
                    <div className="flex flex-col space-y-0.5">
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest leading-none">
                        {prod.unitText}
                      </span>
                      <span className={`text-[17px] font-black tracking-tight ${prod.isPremiumPrice ? "text-[#0b1c3f]" : "text-[#2563eb]"}`}>
                        {prod.priceText}
                      </span>
                    </div>

                    {/* Highly responsive button action matching stitch mockup images */}
                    <div className="flex flex-col space-y-2 w-full">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleAddAction(prod)}
                          className={`flex-grow font-extrabold text-xs py-3 rounded-2xl flex items-center justify-center space-x-2 transition-all duration-300 cursor-pointer shadow-xs ${
                            addedProductId === prod.id
                              ? "bg-emerald-600 text-white hover:bg-emerald-700"
                              : "bg-[#10b981] hover:bg-[#059669] text-white"
                          }`}
                        >
                          <Check className="w-4 h-4 text-white" />
                          <span>{addedProductId === prod.id ? "Eklendi" : "Teklif Listesine Ekle"}</span>
                        </button>

                        {prod.baski === "Baskısız" && (
                          <button
                            title="Baskılı Üretim İste"
                            onClick={() => {
                              const url = `/teklif.html?urun=${encodeURIComponent(prod.name)}&malzeme=${encodeURIComponent(prod.malzeme)}&kalinlik=${encodeURIComponent(prod.specValue)}&baski_durumu=Baskılı`;
                              window.history.pushState({}, "", url);
                              onCustomizeWithAI(`${prod.name} için malzeme: ${prod.malzeme}, kalınlık: ${prod.specValue}. baski_durumu: Baskılı özel fiyat teklifi almak istiyorum.`);
                            }}
                            className="bg-white border-2 border-[#0b1c3f] hover:bg-[#0b1c3f]/5 text-[#0b1c3f] font-extrabold text-xs p-3 rounded-2xl flex items-center justify-center transition-all duration-300 cursor-pointer shrink-0"
                          >
                            <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
                          </button>
                        )}
                      </div>
                    </div>

                  </div>

                </div>
              ))}
            </div>

            {/* Pagination HUD align matching bottom center of Image 3 exactly */}
            <div className="flex items-center justify-center space-x-1.5 pt-8" id="pagination-controls-row">
              <button className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-400 hover:bg-slate-50">&lt;</button>
              <button className="w-8 h-8 rounded-lg bg-[#0b1c3f] border border-[#0b1c3f] flex items-center justify-center text-xs font-bold text-white shadow-xs">1</button>
              <button className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500 hover:bg-slate-50">2</button>
              <button className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500 hover:bg-slate-50">3</button>
              <span className="text-slate-400 text-xs px-1">...</span>
              <button className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-500 hover:bg-slate-50">12</button>
              <button className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-400 hover:bg-slate-50">&gt;</button>
            </div>

          </main>

        </div>
      </div>
      <Footer setTab={setTab} />
    </div>
  );
}
