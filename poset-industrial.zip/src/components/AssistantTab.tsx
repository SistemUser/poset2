import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, Send, Box, Cpu, FileSpreadsheet, Package, 
  HelpCircle, CheckCircle2, ChevronRight, Activity, Trash2, 
  Settings2, Download, AlertCircle, ShoppingCart, Lock,
  RefreshCw, FileQuestion, ShoppingBag, Clock, Check,
  Paperclip, FileUp
} from "lucide-react";
import { IMAGES } from "../constants";
import { ChatMessage, QuoteSpec, ImageType } from "../types";
import { CATEGORIES, TAXONOMY_PRODUCTS } from "../productsData";

// Dynamic dimension choices by category group
const DIMENSIONS_BY_GROUP = {
  kargo: ["20x30 cm", "24x32 cm", "28x38 cm", "30x40 cm", "35x45 cm", "40x50 cm", "45x55 cm", "50x60 cm"],
  fatura: ["18x24 cm (A5)", "24x32 cm (A4)"],
  magaza: ["20x30 cm", "26x38 cm", "30x40 cm", "40x50 cm", "50x60 cm", "60x70 cm"],
  market: ["26x45 cm (Küçük)", "30x55 cm (Orta)", "35x60 cm (Büyük)", "45x75 cm (Battal)"],
  kilitli: ["8.5x13 cm", "11x18.5 cm", "13x22.5 cm", "16x27 cm", "20x30 cm"],
  opp: ["10x15 cm", "15x25 cm", "20x30 cm", "25x35 cm", "30x40 cm"],
  kagit: ["18x24 cm", "25x31 cm", "32x41 cm", "40x42 cm", "54x48 cm"],
  bez: ["25x30 cm", "30x40 cm", "35x40 cm", "40x45 cm", "50x50 cm"],
  saf: ["50 cm Rulo Eni", "100 cm Rulo Eni", "120 cm Rulo Eni", "150 cm Rulo Eni"]
};

const getProductGroupKey = (spec: QuoteSpec): keyof typeof DIMENSIONS_BY_GROUP => {
  const closureLower = (spec.closure || "").toLowerCase();
  const materialLower = (spec.material || "").toLowerCase();
  const colorLower = (spec.color || "").toLowerCase();
  
  // 1. Fatura Cebi ve İrsaliye Zarfları
  if (materialLower.includes("şeffaf pe yapışkanlı") || closureLower.includes("sırt bölgesi") || closureLower.includes("fatura zarfı") || closureLower.includes("irsaliye zarfları")) {
    return "fatura";
  }
  
  // 2. Balonlu Patpat Naylonlar / Şrink Filmler (check rule/rulo/şrink/shrink)
  if (materialLower.includes("rulo") || closureLower.includes("rulo") || materialLower.includes("şrink") || materialLower.includes("shrink") || materialLower.includes("tüneli") || materialLower.includes("patpat") || materialLower.includes("kabarcıklı ldpe (rulo)")) {
    if (!closureLower.includes("zarf") && !closureLower.includes("kapak")) {
      return "saf";
    }
  }

  // 3. Bez ve Tela Çantalar
  if (materialLower.includes("tela") || materialLower.includes("nonwoven") || materialLower.includes("bez") || materialLower.includes("pamuk") || materialLower.includes("elyaf")) {
    return "bez";
  }

  // 4. Market Poşetleri (Atlet)
  if (materialLower.includes("hışır") || closureLower.includes("atlet") || closureLower.includes("çift kulplu") || materialLower.includes("atlet")) {
    return "market";
  }

  // 5. Kilitli & Fermuarlı Poşetler
  if (closureLower.includes("zip") || closureLower.includes("kilit") || closureLower.includes("fermuarlı") || materialLower.includes("laminasyon")) {
    if (materialLower.includes("bariyer") || materialLower.includes("metalize") || materialLower.includes("doypack")) {
      return "kilitli";
    }
  }

  // 6. Jelatin & OPP / Biyobozunur Poşetler
  if (materialLower.includes("opp") || materialLower.includes("jelatin") || materialLower.includes("biyobozunur") || materialLower.includes("kompost") || materialLower.includes("pla")) {
    return "opp";
  }

  // 7. Kağıt, Kraft ve Lüks Karton Çantalar
  if (spec.imageType === "kraft" || materialLower.includes("bristol") || materialLower.includes("sülfit") || materialLower.includes("karton") || materialLower.includes("kağıt büküm") || closureLower.includes("büküm sap") || materialLower.includes("kraft")) {
    if (!closureLower.includes("silikon bant") && !closureLower.includes("iade")) {
      return "kagit";
    }
  }

  // 8. Kargo Poşetleri Grubu
  if (spec.imageType === "kargo" || closureLower.includes("kapak") || closureLower.includes("bantlı") || closureLower.includes("permanent") || closureLower.includes("kargo") || materialLower.includes("co-ex")) {
    return "kargo";
  }

  // 9. Mağaza Poşetleri (El Geçme, Takviyeli, Yumuşak Saplı)
  if (spec.imageType === "magaza" || materialLower.includes("ldpe") || closureLower.includes("el geçmeli") || closureLower.includes("şerit sap")) {
    return "magaza";
  }

  return "magaza"; // fallback
};

const getPopularDimension = (groupKey: keyof typeof DIMENSIONS_BY_GROUP): string => {
  switch (groupKey) {
    case "kargo": return "30x40 cm";
    case "fatura": return "18x24 cm (A5)";
    case "magaza": return "30x40 cm";
    case "market": return "30x55 cm (Orta)";
    case "kilitli": return "13x22.5 cm";
    case "opp": return "20x30 cm";
    case "kagit": return "25x31 cm";
    case "bez": return "35x40 cm";
    case "saf": return "100 cm Rulo Eni";
    default: return "30x40 cm";
  }
};

const parseDimensionMetrics = (dimStr: string): { area: number; length: number; isRoll: boolean } => {
  const clean = dimStr.toLowerCase();
  
  if (clean.includes("rulo") || clean.includes("eni")) {
    const match = clean.match(/(\d+)/);
    const width = match ? parseFloat(match[1]) : 100;
    return { area: 0, length: width, isRoll: true };
  }

  const numbers = clean.match(/(\d+(?:\.\d+)?)\s*x\s*(\d+(?:\.\d+)?)/) || 
                  clean.match(/(\d+(?:\.\d+)?)\s*\*\s*(\d+(?:\.\d+)?)/) ||
                  clean.split(/[^0-9.]+/).filter(Boolean).map(parseFloat);
  
  if (numbers && numbers.length >= 2) {
    const width = parseFloat(String(numbers[0]));
    const height = parseFloat(String(numbers[1]));
    return { area: width * height, length: 0, isRoll: false };
  }

  return { area: 1200, length: 0, isRoll: false };
};

interface AssistantTabProps {
  initialPrompt: string | null;
  onClearInitialPrompt: () => void;
  onPlaceOrder: (spec: QuoteSpec) => void;
}

export default function AssistantTab({ initialPrompt, onClearInitialPrompt, onPlaceOrder }: AssistantTabProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeSpec, setActiveSpec] = useState<QuoteSpec | null>(null);
  const [selectedQuickCategory, setSelectedQuickCategory] = useState<string>("kargo_eticaret");
  
  // Custom Logo Attachment & Drag-Drop State
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  // Persistent Logo URL & File Name state for layered canvasing
  const [persistentLogoUrl, setPersistentLogoUrl] = useState<string | null>(null);
  const [persistentLogoName, setPersistentLogoName] = useState<string | null>(null);
  
  // Spec Fine-Tuning State
  const [adjustedQty, setAdjustedQty] = useState<number>(10000);
  const [adjustedThickness, setAdjustedThickness] = useState<number>(80);
  const [adjustedBaski, setAdjustedBaski] = useState<"standart" | "premium" | "eco">("standart");
  const [adjustedBaskiTercihi, setAdjustedBaskiTercihi] = useState<"Baskılı" | "Baskısız">("Baskılı");
  const [adjustedRenkSayisi, setAdjustedRenkSayisi] = useState<string>("Lütfen Renk Sayısı Seçin");
  const [selectedDim, setSelectedDim] = useState<string>("30x40 cm");
  const [customDim, setCustomDim] = useState<string>("");
  const [addAdhesivePocket, setAddAdhesivePocket] = useState<boolean>(false);
  
  // Download Spec PDF State
  const [isSpecDownloaded, setIsSpecDownloaded] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  // Order Confirmation Overlay State
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerCompany, setCustomerCompany] = useState("");
  const [orderPlacedSuccess, setOrderPlacedSuccess] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Default fallback baseline mock spec setup
  const defaultSpec: QuoteSpec = {
    dimensions: "35 x 45 cm",
    material: "Alçak Yoğunluk Polietilen (LDPE)",
    thickness: "80 Mikron",
    closure: "Takviyeli El Geçmeli Sap",
    color: "Parlak Beyaz / Siyah Özel Baskılı",
    leadTime: "12-14 İş Günü",
    moq: "10.000 Adet",
    unitPrice: "₺1.85",
    totalPrice: "₺18.500",
    imageType: "magaza",
    customDetails: [
      "Canlı flexo 8 renk baskı çözünürlüğü",
      "Kopmaları önleyici takviye kaynak dolgusu",
      "FDA standartlarında gıdaya temas sertifikası"
    ],
    ecoScore: 70
  };

  // Identify if active product is kilograms or pieces (based on MOQ unit string)
  const isKgBased = activeSpec ? activeSpec.moq.toLowerCase().includes("kg") : false;

  // Synchronize dynamic parameters when activeSpec updates
  useEffect(() => {
    if (activeSpec) {
      const parsedQty = parseInt(activeSpec.moq.replace(/[^0-9]/g, "")) || (activeSpec.moq.toLowerCase().includes("kg") ? 500 : 10000);
      setAdjustedQty(parsedQty);

      const parsedThickness = parseInt(activeSpec.thickness.replace(/[^0-9]/g, "")) || 80;
      setAdjustedThickness(parsedThickness);
      
      setAdjustedBaski("standart");
      setIsSpecDownloaded(false);

      if (activeSpec.baskiDurumu) {
        setAdjustedBaskiTercihi(activeSpec.baskiDurumu);
      } else {
        setAdjustedBaskiTercihi("Baskılı");
      }

      if (activeSpec.renkSayisi) {
        setAdjustedRenkSayisi(activeSpec.renkSayisi);
      } else {
        setAdjustedRenkSayisi("2 Renk");
      }

      const groupKey = getProductGroupKey(activeSpec);
      const standardOptions = DIMENSIONS_BY_GROUP[groupKey];
      const normalizedSpecDim = activeSpec.dimensions ? activeSpec.dimensions.toLowerCase().replace(/\s+/g, "").replace(/x/g, "x").replace(/\*/g, "x") : "";
      
      let matchedDim = "";
      if (normalizedSpecDim) {
        matchedDim = standardOptions.find(opt => {
          const normalizedOpt = opt.toLowerCase().replace(/\s+/g, "").replace(/x/g, "x").split("(")[0].trim();
          return normalizedSpecDim.includes(normalizedOpt) || normalizedOpt.includes(normalizedSpecDim);
        }) || "";
      }

      if (matchedDim) {
        setSelectedDim(matchedDim);
        setCustomDim("");
      } else if (activeSpec.dimensions) {
        setSelectedDim(activeSpec.dimensions);
        setCustomDim("");
      } else {
        const pop = getPopularDimension(groupKey);
        setSelectedDim(pop);
        setCustomDim("");
      }
      setAddAdhesivePocket(false);
    }
  }, [activeSpec]);

  // Recalculating Formula Engine
  const baseQty = activeSpec ? (parseInt(activeSpec.moq.replace(/[^0-9]/g, "")) || (isKgBased ? 500 : 10000)) : (isKgBased ? 500 : 10000);
  const baseThickness = activeSpec ? (parseInt(activeSpec.thickness.replace(/[^0-9]/g, "")) || 80) : 80;
  
  const parsePrice = (priceStr: string): number => {
    const cleaned = priceStr.replace(/[^0-9.,]/g, "").replace(",", ".");
    const val = parseFloat(cleaned);
    return isNaN(val) ? 1.85 : val;
  };
  const baseUnitPrice = activeSpec ? parsePrice(activeSpec.unitPrice) : 1.85;

  // Quantity Tier discounts adapted for Adet vs Kg
  const qtyMultiplier = (() => {
    const qty = adjustedQty;
    if (isKgBased) {
      if (qty <= 150) return 1.45;
      if (qty <= 300) return 1.25;
      if (qty <= 600) return 1.0;
      if (qty <= 1200) return 0.90;
      if (qty <= 2500) return 0.82;
      return 0.74;
    } else {
      if (qty <= 2000) return 1.45;
      if (qty <= 5000) return 1.20;
      if (qty <= 10000) return 1.0;
      if (qty <= 20000) return 0.90;
      if (qty <= 35000) return 0.82;
      return 0.74; 
    }
  })();

  // Thickness weight modifier
  const thicknessDiffPercent = baseThickness > 0 ? (adjustedThickness - baseThickness) / baseThickness : 0;
  const thicknessFactor = 1 + thicknessDiffPercent * 0.45; 

  // Option modifiers
  const baskiModifiers = {
    standart: 0,
    premium: 0.35, 
    eco: -0.15 
  };
  const baskiModifier = baskiModifiers[adjustedBaski];

  // Choice modifier based on printing (Baskılı vs Baskısız) and selected exact color options
  const colorPriceMultiplier = (() => {
    if (adjustedBaskiTercihi === "Baskısız") return 0.82; // 18% discount for unprinted
    switch (adjustedRenkSayisi) {
      case "1 Renk": return 0.95;
      case "2 Renk": return 1.0;
      case "3 Renk": return 1.08;
      case "4 Renk (CMYK)": return 1.16;
      case "5+ Renk / Özel Renk": return 1.25;
      default: return 1.0;
    }
  })();

  // Calculate scale factor based on selected dimension vs the baseline spec dimensions
  const dimensionPriceMultiplier = (() => {
    if (!activeSpec) return 1.0;
    
    const baselineMetrics = parseDimensionMetrics(activeSpec.dimensions);
    const selectedMetrics = parseDimensionMetrics(selectedDim === "Diğer / Özel Ölçü" ? customDim : selectedDim);

    if (baselineMetrics.isRoll && selectedMetrics.isRoll) {
      return selectedMetrics.length / Math.max(1, baselineMetrics.length);
    } else if (!baselineMetrics.isRoll && !selectedMetrics.isRoll) {
      const ratio = selectedMetrics.area / Math.max(1, baselineMetrics.area);
      return Math.max(0.6, 0.4 + 0.6 * ratio);
    } else {
      return 1.0;
    }
  })();

  const isKargoCategory = activeSpec ? (
    getProductGroupKey(activeSpec) === "kargo" || 
    getProductGroupKey(activeSpec) === "fatura" || 
    activeSpec.imageType === "kargo" ||
    activeSpec.dimensions.includes("Kargo") ||
    (activeSpec.closure || "").toLowerCase().includes("kargo") ||
    (activeSpec.material || "").toLowerCase().includes("co-ex")
  ) : false;

  // Calculated display prices
  const baseActiveUnitPriceVal = Math.max(0.40, (baseUnitPrice * qtyMultiplier * thicknessFactor * colorPriceMultiplier * dimensionPriceMultiplier) + (adjustedBaskiTercihi === "Baskılı" ? baskiModifier : 0));
  const activeUnitPriceVal = baseActiveUnitPriceVal + (addAdhesivePocket && isKargoCategory ? 0.24 : 0);
  const activeTotalPriceVal = activeUnitPriceVal * adjustedQty;

  const displayUnitPriceStr = `₺${activeUnitPriceVal.toFixed(2)}`;
  const displayTotalPriceStr = `₺${Math.round(activeTotalPriceVal).toLocaleString("tr-TR")}`;

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const validateAndSetFile = (file: File) => {
    const allowedExtensions = ["pdf", "ai", "cdr", "eps", "png", "jpg", "jpeg"];
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (allowedExtensions.includes(ext)) {
      setUploadedFile(file);
      setPersistentLogoName(file.name);
      if (["png", "jpg", "jpeg"].includes(ext)) {
        const url = URL.createObjectURL(file);
        setPersistentLogoUrl(url);
      } else {
        setPersistentLogoUrl("vector_placeholder");
      }
      triggerToast(`✓ Logo "${file.name}" başarıyla eklendi.`);
    } else {
      triggerToast("❌ Sadece .pdf, .ai, .cdr, .eps, .png ve .jpg formatları kabul edilir.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const removeUploadedFile = () => {
    setUploadedFile(null);
    setPersistentLogoUrl(null);
    setPersistentLogoName(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    triggerToast("Logo dosyası kaldırıldı.");
  };

  const handleDownloadSpecDoc = () => {
    setIsSpecDownloaded(true);
    triggerToast("✓ Şartname belgesi (Ambalaj_Sartname_Belgesi.pdf) cihazınıza indirildi.");
  };

  const getOptionsForGroup = (): string[] => {
    if (!activeSpec) return [];
    const groupKey = getProductGroupKey(activeSpec);
    const standardOptions = DIMENSIONS_BY_GROUP[groupKey];
    
    // Check if activeSpec.dimensions is already a standard option
    const normalizedSpecDim = activeSpec.dimensions ? activeSpec.dimensions.toLowerCase().replace(/\s+/g, "").replace(/x/g, "x").replace(/\*/g, "x") : "";
    let hasMatch = false;
    
    if (normalizedSpecDim) {
      hasMatch = standardOptions.some(opt => {
        const normalizedOpt = opt.toLowerCase().replace(/\s+/g, "").replace(/x/g, "x").split("(")[0].trim();
        return normalizedSpecDim === normalizedOpt || normalizedSpecDim.includes(normalizedOpt) || normalizedOpt.includes(normalizedSpecDim);
      });
    }

    const resultOptions = [...standardOptions];
    if (activeSpec.dimensions && !hasMatch && activeSpec.dimensions !== "Diğer / Özel Ölçü") {
      if (!resultOptions.includes(activeSpec.dimensions)) {
        resultOptions.push(activeSpec.dimensions);
      }
    }
    
    if (!resultOptions.includes("Diğer / Özel Ölçü")) {
      resultOptions.push("Diğer / Özel Ölçü");
    }

    return resultOptions;
  };

  // Build overridden dynamic QuoteSpec object to submit
  const getAdjustedSpec = (): QuoteSpec => {
    if (!activeSpec) return defaultSpec;
    const labelUnit = activeSpec.thickness.includes("gr") ? "gr/m²" : "Mikron";
    
    const details = [...activeSpec.customDetails];
    if (adjustedBaski === "premium" && !details.some(d => d.includes("8 renk"))) {
      details.push("8 Renk Ekstra Canlı Flekso Baskı Katkısı");
    } else if (adjustedBaski === "eco" && !details.some(d => d.includes("Geri Dönüşüm"))) {
      details.push("Optimum oranlı çevre dostu bio-bozunur katkı formülasyonu");
    }

    if (addAdhesivePocket && isKargoCategory) {
      details.push("Ekstra Yapışkanlı Fatura Cebi (Paket/Koli Uyumlu)");
    }

    return {
      ...activeSpec,
      dimensions: selectedDim === "Diğer / Özel Ölçü" ? (customDim || "Özel Ölçü") : selectedDim,
      moq: `${adjustedQty.toLocaleString("tr-TR")} ${isKgBased ? "Kg" : "Adet"}`,
      thickness: `${adjustedThickness} ${labelUnit}`,
      unitPrice: displayUnitPriceStr,
      totalPrice: displayTotalPriceStr,
      color: adjustedBaski === "premium" 
        ? `${activeSpec.color} / Ultra HD 8 Renk` 
        : (adjustedBaski === "eco" ? `${activeSpec.color} / d2w Biyo-Çözünür Katkılı` : activeSpec.color),
      customDetails: details,
      ecoScore: adjustedBaski === "eco" ? Math.min(100, (activeSpec.ecoScore || 70) + 15) : (activeSpec.ecoScore || 70)
    };
  };

  // Start chat list lifecycle (Note: we leave activeSpec as null initial to display the Image 2 blueprint layout!)
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: "greet-1",
          role: "assistant",
          content: "Merhaba! Hayalinizdeki ambalaj poşetini tarif edin, saniyeler içinde size özel üretim maliyeti ve teknik şartname dökümünü hazırlayayım.",
          timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    }
  }, []);

  // Monitor initial prompt triggers
  useEffect(() => {
    if (initialPrompt) {
      handleSendPrompt(initialPrompt);
      onClearInitialPrompt();
    }
  }, [initialPrompt]);

  // Scroll logic helper
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSendPrompt = async (textToSend: string) => {
    if (!textToSend.trim() && !uploadedFile) return;

    let finalPrompt = textToSend;
    if (uploadedFile) {
      if (finalPrompt) {
        finalPrompt += ` [Ekli Logo Dosyası: ${uploadedFile.name}]`;
      } else {
        finalPrompt = `[Logo Dosyası Yüklendi: ${uploadedFile.name}]`;
      }
    }

    const userMsg: ChatMessage = {
      id: `m-user-${Date.now()}`,
      role: "user",
      content: finalPrompt,
      timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev, userMsg]);
    setUserInput("");
    setUploadedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setLoading(true);

    try {
      const response = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: finalPrompt })
      });

      if (!response.ok) {
        throw new Error("Sunucu yanıt vermedi");
      }

      const responseText = await response.text();
      let data: any = {};
      try {
        if (responseText && responseText.trim() !== "undefined" && responseText.trim() !== "") {
          data = JSON.parse(responseText);
        } else {
          console.warn("Empty or undefined response received from server.");
        }
      } catch (parseError) {
        console.error("Error parsing response JSON:", responseText, parseError);
        throw new Error("Sunucu geçersiz bir veri döndürdü.");
      }
      
      const assistantMsg: ChatMessage = {
        id: `m-ai-${Date.now()}`,
        role: "assistant",
        content: data.assistantText || "Teknik özellikleri başarıyla derledim. Sağ taraftan şartname parametrelerini revize edebilirsiniz.",
        timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
        quoteSpec: data.spec
      };

      setMessages(prev => [...prev, assistantMsg]);
      if (data.spec) {
        setActiveSpec(data.spec);
      } else {
        // Fallback calculation for rich offline experience
        setActiveSpec(defaultSpec);
      }

    } catch (error) {
      console.error("Error fetching AI spec:", error);
      // Soft backup for server timeout
      const assistantMsg: ChatMessage = {
        id: `m-ai-${Date.now()}`,
        role: "assistant",
        content: "Teknik analizi başarıyla tamamladım. Girdiğiniz bilgilere göre en yakın üretim şartnamesini yan tarafta inceleyebilir ve esnekçe revize edebilirsiniz.",
        timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
      };
      setMessages(prev => [...prev, assistantMsg]);
      setActiveSpec(defaultSpec);
    } finally {
      setLoading(false);
    }
  };

  const getImageSource = (type: ImageType): string => {
    switch (type) {
      case "kargo":
        return IMAGES.kargoBag;
      case "kraft":
        return IMAGES.kraftBag;
      case "magaza":
        return IMAGES.magazaBag;
      case "gida":
        return IMAGES.adhesivePockets;
      case "bubble":
        return IMAGES.moq3DPreview;
      default:
        return IMAGES.kargoBag;
    }
  };

  const getEcoScoreColor = (score?: number): string => {
    if (!score) return "text-emerald-500 bg-emerald-50";
    if (score >= 85) return "text-emerald-600 bg-emerald-50 border border-emerald-100";
    if (score >= 65) return "text-indigo-600 bg-indigo-50 border border-indigo-100";
    return "text-slate-600 bg-slate-50 border border-slate-100";
  };

  const handleOpenOrderModal = () => {
    if (activeSpec) {
      setShowOrderModal(true);
      setOrderPlacedSuccess(false);
    }
  };

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;

    const finalSpec = getAdjustedSpec();
    onPlaceOrder(finalSpec);
    setOrderPlacedSuccess(true);
    
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          id: `order-ai-${Date.now()}`,
          role: "assistant",
          content: `Tebrikler ${customerName}! Yapılandırdığınız **${finalSpec.moq}** üretim hacmindeki özelleştirilmiş ambalaj sipariş talebiniz fabrika sistemimize işlenmiştir. Uzman ekibimiz sizinle **${customerPhone}** numaralı telefondan en kısa sürede iletişime geçip dijital onay taslaklarını iletecektir.`,
          timestamp: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
        }
      ]);
      setShowOrderModal(false);
      setCustomerName("");
      setCustomerPhone("");
      setCustomerCompany("");
    }, 1200);
  };

  // Predefined prompt helper
  const handleQuickChipSelect = (promptTitle: string, userPromptText: string) => {
    setUserInput(userPromptText);
    handleSendPrompt(userPromptText);
  };

  return (
    <div className="py-10 px-6 max-w-7xl mx-auto bg-[#fcfdfd] min-h-screen" id="assistant-tab-root">
      <div className="grid lg:grid-cols-12 gap-8 items-stretch">
        
        {/* Left Column: AKILLI TEKLİF MERKEZİ */}
        <div className="lg:col-span-7 bg-white border border-slate-200/85 p-7.5 rounded-3xl shadow-xs flex flex-col justify-between space-y-6 h-[760px] overflow-y-auto">
          
          <div className="space-y-5">
            {/* Topic Details mapping Image 2 perfectly */}
            <div className="space-y-1.5">
              <h2 className="text-xl sm:text-[23px] font-black text-[#0f172a] tracking-tight">
                Fiyat Teklif Merkezi
              </h2>
            </div>

            {/* Quick recommendation pill chips */}
            <div className="space-y-3.5 pt-1" id="quick-quote-chips-container">
              {/* Category Dropdown Selector */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <span className="text-[10px] font-mono font-black text-slate-400 uppercase tracking-widest">
                  Hızlı Şablon Seç:
                </span>
                <select
                  value={selectedQuickCategory}
                  onChange={(e) => setSelectedQuickCategory(e.target.value)}
                  className="bg-white border border-slate-200 text-xs font-bold text-slate-700 px-3 py-1.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0b1c3f] cursor-pointer shadow-3xs"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat.key} value={cat.key}>
                      {cat.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Dynamic Product Sub-Chips List */}
              <div className="flex flex-wrap gap-1.5" id="quick-quote-chips-row">
                {TAXONOMY_PRODUCTS.filter(p => p.categoryKey === selectedQuickCategory).map((prod) => {
                  const defaultPrompt = `Kurumsal marka prestijimizi ön plana çıkarmak amacıyla, ${prod.name} ambalajı üzerine özel logo tasarımlı baskılı bir ambalaj teknik şartnamesi ve fiyat teklifi oluşturulmasını rica ediyorum. Şartnamede kalınlığı ${prod.specValue} ve adet miktarını sektörel standartlarda tasarlayalım.`;
                  return (
                    <button
                      key={prod.id}
                      type="button"
                      onClick={() => handleQuickChipSelect(prod.name, defaultPrompt)}
                      className="inline-flex items-center space-x-1.5 bg-slate-50 hover:bg-[#0b1c3f] hover:text-white border border-slate-200/80 px-3 py-1.5 rounded-xl text-xs font-bold text-[#0b1c3f] hover:text-white transition-all cursor-pointer shadow-3xs hover:-translate-y-0.5 active:translate-y-0"
                    >
                      <Package className="w-3.5 h-3.5 opacity-60 shrink-0" />
                      <span>{prod.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Large White request template Box container holding Textarea and Circular submit button */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendPrompt(userInput);
              }}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`rounded-2xl border p-3 shadow-md shadow-slate-100/50 flex flex-col justify-between gap-3 relative transition-all ${
                isDragging 
                  ? "bg-indigo-50/50 border-[#0b1c3f] border-2 border-dashed animate-pulse" 
                  : "bg-white border-slate-200 focus-within:border-[#0b1c3f]"
              }`}
            >
              <textarea
                rows={4}
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Örn: 30x40 ölçülerinde, baskılı, 50 mikron kalınlığında kargo poşeti istiyorum. Aylık 10.000 adet tüketimimiz var..."
                className="w-full bg-transparent border-none text-xs text-slate-700 leading-relaxed font-semibold focus:outline-none focus:ring-0 p-2.5 resize-none placeholder-slate-400/80 min-h-[90px]"
              />

              {/* Hidden File Input */}
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".pdf,.ai,.cdr,.eps,.png,.jpg,.jpeg"
                onChange={handleFileChange}
              />

              {/* Uploaded File Indicator chip */}
              {uploadedFile && (
                <div className="flex items-center justify-between mx-2.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700">
                    <FileUp className="w-3.5 h-3.5 text-indigo-600 animate-bounce" />
                    <span className="truncate max-w-[180px] font-mono text-[10px]">{uploadedFile.name} ({Math.round(uploadedFile.size / 1024)} KB)</span>
                  </div>
                  <button
                    type="button"
                    onClick={removeUploadedFile}
                    className="text-xs font-extrabold text-rose-500 hover:text-rose-700 font-sans focus:outline-none shrink-0 cursor-pointer"
                  >
                    ✕ İptal
                  </button>
                </div>
              )}

              {/* Action layout button row */}
              <div className="flex items-center justify-between p-1.5 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs rounded-xl flex items-center space-x-1.5 transition-all cursor-pointer select-none"
                  title="Logo Dosyası Ekle (.pdf, .ai, .cdr, .eps, .png, .jpg)"
                >
                  <Paperclip className="w-3.5 h-3.5 text-slate-400" />
                  <span>Logo Ekle</span>
                </button>

                <button
                  type="submit"
                  disabled={loading || (!userInput.trim() && !uploadedFile)}
                  className="w-9 h-9 bg-[#0b1c3f] hover:bg-[#07132c] text-white rounded-full flex items-center justify-center transition-all cursor-pointer shadow-sm disabled:bg-slate-100 disabled:text-slate-400"
                >
                  <Send className="w-4 h-4 text-white" />
                </button>
              </div>
            </form>

            <p className="text-[10px] text-slate-400 font-bold leading-normal font-sans pt-1">
              • Yapay zeka asistanı detayları analiz ederek sağ tarafta dinamik bir önizleme oluşturacaktır.
            </p>

          </div>

          {/* Collaborative Dialog log inside separate area below, displayed if messages are present */}
          {messages.length > 0 && (
            <div className="border-t border-slate-100 pt-5 flex-grow overflow-y-auto max-h-[340px] space-y-4" id="integrative-chat-flow">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">İletişim Kanalı & Asistan Analiz Günlüğü</span>
              
              <div className="space-y-3.5">
                {messages.map((m) => {
                  const contentLower = m.content.toLowerCase();
                  const isLogoRequested = m.role === "assistant" && (
                    contentLower.includes("logo") ||
                    contentLower.includes("görsel") ||
                    contentLower.includes("gönder") ||
                    contentLower.includes("iletebilir") ||
                    contentLower.includes("yükle") ||
                    contentLower.includes("baskı") ||
                    contentLower.includes("tasarım")
                  );

                  return (
                    <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[90%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                        m.role === "user" 
                          ? "bg-[#0b1c3f] text-white rounded-br-none" 
                          : "bg-slate-50 text-slate-700 border border-slate-100 rounded-bl-none"
                      }`}>
                        <p className="whitespace-pre-line font-medium">{m.content}</p>
                        
                        {m.quoteSpec && m.role === "assistant" && (
                          <button
                            type="button"
                            onClick={() => setActiveSpec(m.quoteSpec!)}
                            className="mt-2 text-[10px] font-bold text-[#e11d48] flex items-center space-x-1 hover:underline cursor-pointer"
                          >
                            <span>Şartname Görünümünü Yükle</span>
                            <span className="font-mono">→</span>
                          </button>
                        )}

                        {isLogoRequested && adjustedBaskiTercihi === "Baskılı" && (
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="mt-3 w-full bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold text-[10px] sm:text-[11px] py-2.5 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md shadow-amber-500/10 hover:shadow-lg hover:shadow-amber-500/20 active:scale-95 text-center select-none"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-white animate-pulse" />
                            <span>Logonu Şimdi Yükle</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}

                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-2xl rounded-bl-none flex items-center space-x-2.5">
                      <div className="w-2.5 h-2.5 bg-indigo-600 rounded-full animate-ping shrink-0" />
                      <span className="text-xs text-slate-400 font-bold font-mono">Formüller ve üretim kapasiteleri değerlendiriliyor...</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Right Column: DİNAMİK ÖNİZLEME */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6" id="digital-preview-col">
          
          {/* Main Card */}
          <div className="bg-white border border-slate-200/85 p-6 rounded-3xl shadow-xs flex-grow flex flex-col justify-between space-y-5">
            
            {/* Top Header of Preview Panel */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 rounded-full bg-indigo-50 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                </div>
                <span className="font-extrabold text-sm text-[#0f172a] uppercase tracking-wider font-sans">
                  Dinamik Önizleme
                </span>
              </div>

              {/* Status Badge right-aligned matching image 2 */}
              <div className="flex items-center space-x-1.5">
                <span className="relative flex h-2 w-2">
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${activeSpec ? "bg-emerald-400" : "bg-amber-400"}`}></span>
                  <span className={`relative inline-flex rounded-full h-2 w-2 ${activeSpec ? "bg-emerald-500" : "bg-amber-500"}`}></span>
                </span>
                <span className="text-[10px] font-bold text-slate-500 font-sans tracking-wide">
                  {activeSpec ? "Şartname Analiz Edildi" : "Bekleniyor"}
                </span>
              </div>
            </div>

            {/* Empty state or Active calculations layout */}
            {!activeSpec ? (
              /* Dotted blank canvas matching image 2 empty state exactly */
              <div className="border border-slate-300 border-dashed rounded-2xl p-8 flex-grow flex flex-col items-center justify-center text-center space-y-4 min-h-[320px]">
                <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center border border-slate-100">
                  <FileQuestion className="w-5 h-5 text-slate-400" />
                </div>
                <div className="space-y-1 max-w-[280px]">
                  <p className="font-bold text-sm text-slate-800">Detayları Bekliyoruz</p>
                  <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                    Sol taraftaki alana talebinizi girdiğinizde, seçtiğiniz ürünün 3D önizlemesi ve teknik detayları burada belirecektir.
                  </p>
                </div>
              </div>
            ) : (
              /* Beautiful active interactive specs dashboard */
              <div className="space-y-5 flex-grow">

                {/* Dynamically Rendered Spec Micro Chips */}
                <div className="flex flex-wrap gap-1.5" id="preview-spec-micro-chips">
                  <span className="bg-indigo-50 text-indigo-700 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-indigo-100">
                    {adjustedQty.toLocaleString("tr-TR")} {isKgBased ? "Kg" : "Adet"}
                  </span>
                  <span className="bg-slate-50 text-slate-700 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-slate-200">
                    {activeSpec.imageType === "kargo" ? "Kargo Poşeti" : (activeSpec.imageType === "kraft" ? "Kraft Çantası" : (activeSpec.imageType === "magaza" ? "Mağaza Poşeti" : "Endüstriyel Ambalaj"))}
                  </span>
                  {adjustedBaskiTercihi === "Baskılı" && (
                    <span className="bg-amber-50 text-amber-700 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-amber-100 animate-pulse">
                      {adjustedRenkSayisi}
                    </span>
                  )}
                  {persistentLogoName && adjustedBaskiTercihi === "Baskılı" && (
                    <span className="bg-emerald-50 text-emerald-700 text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-emerald-100 truncate max-w-[120px]">
                      {persistentLogoName}
                    </span>
                  )}
                </div>
                
                {/* 3D Blueprint Canvas Wrapper */}
                <div className="relative h-56 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex items-center justify-center group">
                  <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none"></div>
                  
                  {/* Hologram alignment grids */}
                  <div className="absolute top-4 left-4 w-3.5 h-3.5 border-t-2 border-l-2 border-indigo-500/60"></div>
                  <div className="absolute top-4 right-4 w-3.5 h-3.5 border-t-2 border-r-2 border-indigo-500/60"></div>
                  <div className="absolute bottom-4 left-4 w-3.5 h-3.5 border-b-2 border-l-2 border-indigo-500/60"></div>
                  <div className="absolute bottom-4 right-4 w-3.5 h-3.5 border-b-2 border-r-2 border-indigo-500/60"></div>

                  <div className="relative w-full h-full flex items-center justify-center">
                    <img
                      src={getImageSource(activeSpec.imageType)}
                      alt="ambalaj blueprint"
                      className="w-full h-full object-contain bg-slate-900/50 filter drop-shadow-[0_4px_12px_rgba(255,255,255,0.05)] transform hover:scale-105 duration-500"
                      referrerPolicy="no-referrer"
                    />

                    {/* Absolute positioned Overlay Logo Layer (Conditionally rendered) */}
                    {adjustedBaskiTercihi === "Baskılı" && (
                      <div className="absolute top-[50%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-[35%] h-[35%] flex items-center justify-center pointer-events-none z-10 bg-transparent">
                        {persistentLogoUrl ? (
                          persistentLogoUrl === "vector_placeholder" ? (
                            <div className="flex flex-col items-center justify-center text-center w-full h-full select-none bg-transparent p-1" style={{ mixBlendMode: "multiply" }}>
                              <svg className="w-8 h-8 mb-1.5 opacity-80 text-slate-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                                <polygon points="12 2 2 7 12 12 22 7 12 2" />
                                <polyline points="2 17 12 22 22 17" />
                                <polyline points="2 12 12 17 22 12" />
                              </svg>
                              <span className="text-[8px] font-black uppercase tracking-wider text-slate-900 truncate max-w-full font-mono" title={persistentLogoName || ""}>
                                {persistentLogoName ? persistentLogoName.split('.')[0] : "VEKTÖREL LOGO"}
                              </span>
                              <span className="text-[6px] text-slate-500 font-bold tracking-widest uppercase">
                                Vektörel Baskı
                              </span>
                            </div>
                          ) : (
                            <img
                              src={persistentLogoUrl}
                              alt="Logo Overlay"
                              className="max-w-full max-h-full object-contain select-none bg-transparent"
                              style={{ mixBlendMode: "multiply", filter: "contrast(1.1) brightness(0.9)" }}
                              referrerPolicy="no-referrer"
                            />
                          )
                        ) : (
                          <div className="border border-slate-700/60 border-dashed rounded p-1.5 flex flex-col items-center justify-center text-center opacity-30 w-full h-full bg-slate-900/40">
                            <span className="text-[7.5px] font-bold text-slate-400 uppercase tracking-widest font-mono">LOGO ALANI</span>
                            <span className="text-[6.5px] text-slate-500 font-medium">Lütfen Logo Yükleyin</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {/* Floating product family tag */}
                  <div className="absolute top-3.5 left-3.5 bg-[#0b1c3f] text-white text-[9px] font-mono font-bold px-3 py-1 rounded shadow-sm uppercase tracking-wider">
                    {activeSpec.imageType === "kargo" ? "KO-EX Kargo Poşeti" : (activeSpec.imageType === "kraft" ? "Kraft Taşıma Çantası" : "Butik Mağaza Torbası")}
                  </div>

                  {/* Ecological score badge */}
                  <div className={`absolute bottom-3.5 right-3.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center space-x-1 ${getEcoScoreColor(adjustedBaski === "eco" ? Math.min(100, (activeSpec.ecoScore || 70) + 15) : (activeSpec.ecoScore || 70))}`}>
                    <span>ECO:</span>
                    <span>{adjustedBaski === "eco" ? Math.min(100, (activeSpec.ecoScore || 70) + 15) : (activeSpec.ecoScore || 70)}%</span>
                  </div>
                </div>

                {/* Live pricing tray block */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 font-sans">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider leading-none mb-1">
                      {isKgBased ? "Kg Birim Fiyat" : "Adet Birim Fiyat"}
                    </span>
                    <span className="text-lg font-black text-emerald-600 font-mono tracking-tight">{displayUnitPriceStr}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider leading-none mb-1">Tahmini Toplam</span>
                    <span className="text-lg font-black text-[#0b1c3f] font-mono tracking-tight">{displayTotalPriceStr}</span>
                  </div>
                </div>

                {/* Revizyon Panel sliders */}
                <div className="space-y-4 border-t border-slate-100 pt-4">
                  <div className="flex items-center space-x-1.5 text-xs font-black text-slate-850 uppercase tracking-wider font-mono">
                    <Settings2 className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Şartname Parametre Revizyonu</span>
                  </div>

                  {/* Quantity Slider */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-semibold">Tüketim Miktarı:</span>
                      <span className="font-extrabold text-indigo-600 font-mono text-[11px]">{adjustedQty.toLocaleString("tr-TR")} {isKgBased ? "Kg" : "Adet"}</span>
                    </div>
                    <input
                      type="range"
                      min={isKgBased ? "100" : "1000"}
                      max={isKgBased ? "5000" : "50000"}
                      step={isKgBased ? "50" : "1000"}
                      value={adjustedQty}
                      onChange={(e) => setAdjustedQty(parseInt(e.target.value))}
                      className="w-full accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
                    />
                    <div className="flex justify-between text-[8px] font-mono font-bold text-slate-400 uppercase">
                      <span>{isKgBased ? "100 Kg" : "1 bin"}</span>
                      <span>{isKgBased ? "500 Kg (MOQ)" : "10 Bin (MOQ)"}</span>
                      <span>{isKgBased ? "5.000 Kg" : "50 bin"}</span>
                    </div>
                  </div>

                  {/* Thickness Limit sliders */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-semibold">Malzeme Kalınlığı (µ):</span>
                      <span className="font-extrabold text-slate-755 font-mono text-[11px]">{adjustedThickness} Mikron</span>
                    </div>
                    <input
                      type="range"
                      min={Math.max(20, Math.round(baseThickness * 0.5))}
                      max={Math.round(baseThickness * 1.8)}
                      step="5"
                      value={adjustedThickness}
                      onChange={(e) => setAdjustedThickness(parseInt(e.target.value))}
                      className="w-full accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
                    />
                  </div>

                  {/* Baskı Tercihi Selector */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-slate-500 text-xs font-semibold block">Baskı Tercihi:</span>
                    <select
                      value={adjustedBaskiTercihi}
                      onChange={(e) => {
                        const val = e.target.value as "Baskılı" | "Baskısız";
                        setAdjustedBaskiTercihi(val);
                        if (val === "Baskısız") {
                          setAdjustedRenkSayisi("Lütfen Renk Sayısı Seçin");
                        } else {
                          setAdjustedRenkSayisi("2 Renk");
                        }
                      }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs font-bold text-slate-800 outline-none focus:border-indigo-500 shadow-2xs cursor-pointer"
                    >
                      <option value="Baskılı">Baskılı (Özel Marka Logolu)</option>
                      <option value="Baskısız">Baskısız (Düz / Standart)</option>
                    </select>
                  </div>

                  {/* Renk Sayısı Selector (Conditionally rendered) */}
                  {adjustedBaskiTercihi === "Baskılı" && (
                    <div className="space-y-1.5 pt-1 animate-in fade-in slide-in-from-top-1 duration-150">
                      <span className="text-slate-500 text-xs font-semibold block">Renk Sayısı:</span>
                      <select
                        value={adjustedRenkSayisi}
                        onChange={(e) => setAdjustedRenkSayisi(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs font-bold text-slate-800 outline-none focus:border-indigo-505 shadow-2xs cursor-pointer"
                      >
                        <option value="Lütfen Renk Sayısı Seçin">Lütfen Renk Sayısı Seçin</option>
                        <option value="1 Renk">1 Renk</option>
                        <option value="2 Renk">2 Renk</option>
                        <option value="3 Renk">3 Renk</option>
                        <option value="4 Renk (CMYK)">4 Renk (CMYK)</option>
                        <option value="5+ Renk / Özel Renk">5+ Renk / Özel Renk</option>
                      </select>
                    </div>
                  )}



                </div>

                {/* Technical Production sheet list table */}
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <span className="text-[10px] font-bold text-slate-400 font-mono tracking-wider uppercase block">Üretim Sartnameleri</span>
                  <div className="divide-y divide-slate-100 text-xs font-semibold">
                    <div className="py-2 flex items-center justify-between gap-2.5">
                      <span className="text-slate-400 shrink-0">Ürün Ölçüleri:</span>
                      <div className="flex flex-col items-end gap-1.5 max-w-[70%]">
                        <select
                          value={selectedDim}
                          onChange={(e) => {
                            setSelectedDim(e.target.value);
                            if (e.target.value !== "Diğer / Özel Ölçü") {
                              setCustomDim("");
                            }
                          }}
                          className="font-extrabold text-slate-800 bg-slate-100/60 hover:bg-slate-100 border border-slate-200 rounded-lg py-1 px-2.5 text-[11px] outline-none transition-all cursor-pointer text-right max-w-full"
                        >
                          <option value="" disabled>Ölçü Seçin ▾</option>
                          {getOptionsForGroup().map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                        {selectedDim === "Diğer / Özel Ölçü" && (
                          <motion.input
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            type="text"
                            placeholder="Örn: 30x40 cm"
                            value={customDim}
                            onChange={(e) => setCustomDim(e.target.value)}
                            className="bg-slate-50 border border-slate-200 text-xs py-1 px-2.5 rounded-lg text-right max-w-full font-bold text-slate-800 focus:border-indigo-500 outline-none placeholder:text-slate-400"
                          />
                        )}
                      </div>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span className="text-slate-400">Ana Malzeme:</span>
                      <span className="font-extrabold text-slate-800">{activeSpec.material}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span className="text-slate-400">Yapılandırma Biçimi:</span>
                      <span className="font-extrabold text-slate-800">{activeSpec.closure}</span>
                    </div>
                  </div>
                </div>

                {/* Dynamic Submit Confirm & Print action buttons */}
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <button
                    onClick={handleOpenOrderModal}
                    className="w-full bg-[#0b1c3f] hover:bg-[#07132c] text-white font-extrabold text-xs py-3.5 rounded-2xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md shadow-[#0b1c3f]/10"
                    id="convert-to-order-btn"
                  >
                    <ShoppingCart className="w-4 h-4 text-white" />
                    <span>Bu Teklifi Siparişe Dönüştür</span>
                  </button>
                </div>

                {/* Side Item: Adhesive shipping envelopes (Conditional & Up-sell) */}
                {isKargoCategory && (
                  <div 
                    onClick={() => setAddAdhesivePocket(!addAdhesivePocket)}
                    className={`border rounded-2xl p-3 px-3.5 transition-all duration-300 select-none cursor-pointer text-xs relative overflow-hidden ${
                      addAdhesivePocket 
                        ? "bg-slate-900 border-slate-900 text-white shadow-md shadow-slate-900/10" 
                        : "bg-slate-50 border-slate-200 text-slate-700 opacity-60 hover:opacity-100"
                    }`}
                  >
                    {/* Top Action Row Containing Checkbox Toggle and Label */}
                    <div className="flex items-center justify-between mb-2 pb-1 border-b border-dashed border-slate-200/50">
                      <span className={`text-[9px] font-black tracking-wider uppercase font-mono ${addAdhesivePocket ? "text-emerald-400" : "text-slate-400"}`}>
                        Uyumlu Paket Kombinasyonu
                      </span>
                      <div className="flex items-center space-x-1.5">
                        <span className="text-[10px] font-bold">Siparişime Ekle</span>
                        <div className={`w-4 h-4 rounded-md border flex items-center justify-center transition-all ${
                          addAdhesivePocket 
                            ? "bg-emerald-500 border-emerald-500 text-white" 
                            : "bg-white border-slate-300 text-transparent"
                        }`}>
                          <svg className="w-2.5 h-2.5 stroke-current stroke-[3.5]" fill="none" viewBox="0 0 24 24">
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={IMAGES.adhesivePockets} 
                          alt="fatura cebi" 
                          className="w-10 h-10 rounded-xl object-cover shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <h6 className={`font-bold text-[11px] ${addAdhesivePocket ? "text-white" : "text-slate-800"}`}>
                            Yapışkanlı Fatura Cebi
                          </h6>
                          <p className={`text-[9px] font-medium leading-normal ${addAdhesivePocket ? "text-slate-300" : "text-slate-400"}`}>
                            Standart Koli & Gönderi Faturası İçin
                          </p>
                        </div>
                      </div>
                      <span className={`font-mono font-extrabold shrink-0 ${addAdhesivePocket ? "text-emerald-300" : "text-slate-500"}`}>
                        +₺0.24 / Adet
                      </span>
                    </div>
                  </div>
                )}

              </div>
            )}

          </div>

          {/* Under Cards MOQ / Production lead boxes - REMAIN at all times matching Image 2 */}
          <div className="grid grid-cols-2 gap-4 font-sans shrink-0" id="moq-production-hud-panels">
            {/* Box 1: MOQ */}
            <div className="bg-white border border-slate-200/85 p-4 rounded-2xl shadow-2xs flex items-center space-x-3.5">
              <div className="bg-slate-50 text-slate-500 p-2.5 rounded-xl border border-slate-100">
                <ShoppingBag className="w-4 h-4 text-slate-500" />
              </div>
              <div>
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block font-semibold leading-none mb-1">
                  MİNİMUM SİPARİŞ MİKTARI (MOQ)
                </span>
                <span className="text-sm font-black text-[#0f172a] leading-none font-mono">
                  {activeSpec ? activeSpec.moq : "-- Adet"}
                </span>
              </div>
            </div>

            {/* Box 2: Lead Time */}
            <div className="bg-white border border-slate-200/85 p-4 rounded-2xl shadow-2xs flex items-center space-x-3.5">
              <div className="bg-slate-50 text-slate-500 p-2.5 rounded-xl border border-slate-100">
                <Clock className="w-4 h-4 text-slate-500" />
              </div>
              <div>
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block font-semibold leading-none mb-1">
                  TAHMİNİ ÜRETİM SÜRESİ
                </span>
                <span className="text-sm font-black text-[#0f172a] leading-none">
                  {activeSpec ? activeSpec.leadTime : "-- İş Günü"}
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Siparişe Dönüştür sliding form Modal overlay */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in-50 zoom-in-95 duration-200">
            {/* Modal Heading */}
            <div className="bg-[#0b1c3f] text-white p-6 relative">
              <button 
                onClick={() => setShowOrderModal(false)}
                className="absolute top-4 right-4 text-slate-300 hover:text-white font-mono text-lg"
              >
                ✕
              </button>
              <div className="space-y-1">
                <h4 className="font-extrabold text-base font-display">Fabrika İmalat Siparişi Oluştur</h4>
                <p className="text-xs text-slate-400 font-medium">Lütfen irtibat koordinatlarınızı girin, şartnameyi imalata alalım.</p>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleOrderSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 font-mono">Ad Soyad / Yetkili</label>
                <input
                  type="text"
                  required
                  placeholder="Caner Aydın"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-xs font-semibold px-3.5 py-3 rounded-xl focus:bg-white focus:outline-none focus:border-[#0b1c3f] text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 font-mono">Telefon Numarası</label>
                <input
                  type="tel"
                  required
                  placeholder="0 (555) 000 00 00"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-xs font-semibold px-3.5 py-3 rounded-xl focus:bg-white focus:outline-none focus:border-[#0b1c3f] text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 font-mono">Firma Ünvanı (Opsiyonel)</label>
                <input
                  type="text"
                  placeholder="Aydın A.Ş. / E-Ticaret"
                  value={customerCompany}
                  onChange={(e) => setCustomerCompany(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-xs font-semibold px-3.5 py-3 rounded-xl focus:bg-white focus:outline-none focus:border-[#0b1c3f] text-slate-800"
                />
              </div>

              {/* Submit panel summary */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-[11px] text-slate-500 font-semibold space-y-1 font-sans">
                <div className="flex justify-between">
                  <span>Üretim Hacmi:</span>
                  <span className="font-extrabold text-[#0f172a]">{adjustedQty.toLocaleString("tr-TR")} Adet</span>
                </div>
                <div className="flex justify-between">
                  <span>Tahmini Fiyat:</span>
                  <span className="font-extrabold text-emerald-600 font-mono text-[11.5px]">{displayTotalPriceStr}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs py-3 rounded-xl text-center cursor-pointer"
                >
                  Geri dön
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-xl text-center cursor-pointer shadow-md shadow-emerald-600/10"
                >
                  Siparişi Tamamla
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating toast alerts */}
      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="fixed bottom-6 right-6 z-50 max-w-md bg-slate-900 border border-slate-800 text-white p-4 rounded-2xl shadow-xl flex items-start space-x-3"
          >
            <div className="bg-emerald-500/15 p-1 rounded-lg text-emerald-400 shrink-0 mt-0.5">
              <Check className="w-4 h-4" />
            </div>
            <p className="text-[11px] font-sans font-semibold leading-relaxed text-slate-200">{toastMessage}</p>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
