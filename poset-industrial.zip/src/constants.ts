export const IMAGES = {
  factoryHero: "https://lh3.googleusercontent.com/aida-public/AB6AXuBVPXKnybVkew3XX-0sLBI-Hpx_Ofm2Tp3KhahPyMrNUoKRZiGd68YnW54I0xwPE9OyOK8iaQOmo_un1p3LRWB9nz8x6EGfOnHHOHZXRfOGSg_6f7sTEw00nbTovC4EllTecOQg4u8DcxovevGpRL6NqZNQGEziUkMl4ubDuJkwH8wj8reLPRQR6g8OEzei-43E0StqdKfMTkdXlAUpsUHd_LJ8gr0KgeTZXGgyiwUrXeamFTtvmZzzYVwPRcyjdYYOiZjoCy2HrH8",
  kargoBag: "https://lh3.googleusercontent.com/aida-public/AB6AXuANf86MiXAgwOwmXjL8G4vSYCUjgNV9X94_HiAla6cMoVTctcuBY_QDG2sBRBpQNqprxqR0KgtaBwdvQZL0WCd7fHT_9WGmF9_JVhu3tcsugplMcJUkaa3yynsiyMBFOSkqJ_Vl_0wt3tsAW55GiBUecnsgD_xGs4WC7IzkG4ZyZwwrWScysRr1TfsCuVPGooG9mo2iKi6YpU-lPxWCZ4L5m-7c3aNy52TEr1doYDzAXKj6P36dBLoRZRzIIoFhkhTvmqMgOtQLurI",
  magazaBag: "https://lh3.googleusercontent.com/aida-public/AB6AXuCi-fDfzwr_IOBB_SzgJNs9ewfPwPmp0ddbvTCUu49T2NGpGjDrItTDE383xODXikvCIiV-U9LXYBWi1UAeZQbZCSdpS12oO6rvjtZVKNgVWCZnAooUJz1S1__F11js4P02KVZ8dz2TJRqr-Xd-JxdyDOAjzoSplrmzSdZ6F_U4x6gdSk51Hx9CxXKRzzenkfViswaB55pYzI7PKJZd6DsDxmqUuRdSJJG579a7uDMKE6IVb5d6P7XeTc3AnNn6SM5GXafGntOmruU",
  kraftBag: "https://lh3.googleusercontent.com/aida-public/AB6AXuBdifPemUhPOSjewynbW_RuE4CtxeKjpekKcOb-cpbHvm_1xoeKFrEYzfnF51VA4EO6IPJK0MJDMakw0jUwiW0097_oSROi5ct-4_i5yv1emzq0ZAeGZRVmu8E5sh-V9SwCtib5WBcO7pOV3Nj_k1RmA0ozeAbl9JqTKLPkB3Z1Rq3r85pqHnIF6YWozi9H-oaeRI-knsN4_kJvhnj5wDk2vLx2Oqqd1eg5trgoOTTzHsDlmRlchFLkJ1o3kluaz0Reb4RhYL6tp9A",
  moq3DPreview: "https://lh3.googleusercontent.com/aida-public/AB6AXuDo7oCo5ZJ6p2f_Tr4_9S6_bYXrOar7owtKQ4B1D9mG7dUQlNkThNw9VZ3zNQFqW49aLK5zXYb7Nk4w5NNq5--FZyeoYsxd_tRioH4Dmm_fYKRm_X4rAFMeweu0dYJ7wkscypicU5ssNmmDoNCe1eLXViEvlusXRGYQz4miiW_edolsSvY8BUpm48IV9CubK4QXvPaY_hcNP7gPq0ZlPUb4nXNwFQoR66C70Zc0zojUf6OrHHCV5icPNBbHV_UtVdyTr7b5lWgNCNA",
  adhesivePockets: "https://lh3.googleusercontent.com/aida-public/AB6AXuARlWSs5nNTPbY8guyjQAlqzwpFR3-2lhxxNFG_XCVRoxByjDRJj_uxG0AlXE3xzvpomUlnr_1no3rrWr9u8DU_0qOHkjTWxnxqRjtp8d2ZgeVR7JN7gPCaLuHlYX1DnHDzBF3WMdKA50pxJKfyk-EaWhNp_pGCYZLx-EqaL6oZDe4-214e6sPy08ByKi5ZHq6f3HKcvxxZQCzcDrNJw-mhFiIMTMBkmXNpjv7TBYuVE79WjS4kYZpkGAKCYQQX_DuEoMh04L6DLMk"
};

export const INITIAL_PRODUCTS = [
  {
    id: "prod-1",
    name: "Premium CO-EX Kargo Poşeti",
    category: "kargo",
    material: "Co-Ex Polietilen (LDPE)",
    thickness: "70",
    pricePerUnit: 1.25,
    currency: "₺",
    moq: 10000,
    imageUrl: IMAGES.kargoBag,
    tags: ["Yırtılmaz", "Opak Siyah Astar", "Kalıcı Yapışkanlı"],
    capacity: "Mini - Midi - Maxi",
    description: "E-ticaret gönderileri için çift kat CO-EX yapısıyla yırtılmaya, patlamaya karşı ekstra dirençli ve özel gizlilik astarlı ambalaj ürünüdür."
  },
  {
    id: "prod-2",
    name: "Geri Dönüştürülebilir Kraft Çanta",
    category: "kraft",
    material: "90-120 gr/m² Kraft Kağıt (FSC Sertifikalı)",
    thickness: "110",
    pricePerUnit: 3.40,
    currency: "₺",
    moq: 5000,
    imageUrl: IMAGES.kraftBag,
    tags: ["Eko-Dostu", "FSC Onaylı", "Güçlendirilmiş Sap"],
    capacity: "Hafif & Orta Yük",
    description: "Sürdürülebilir ticaret ilkelerine duyarlı çevre dostu kraft çanta; mağaza, gıda ve paket servis süreçleri için dayanıklı ve şık taşıma çözümü."
  },
  {
    id: "prod-3",
    name: "El Geçmeli Mağaza / Butik Poşeti",
    category: "magaza",
    material: "Alçak Yoğunluk Polietilen (LDPE)",
    thickness: "80",
    pricePerUnit: 1.85,
    currency: "₺",
    moq: 10000,
    imageUrl: IMAGES.magazaBag,
    tags: ["8 Renk Baskı", "Canlı Görünüm", "Yumuşak Tuşe"],
    capacity: "Butik Perakende",
    description: "Marka kimliğinizi en iyi yansıtan, yüksek parlaklıkta ve canlı baskı imkanına sahip yumuşak saplı veya el geçmeli özel perakende taşıma çantası."
  },
  {
    id: "prod-4",
    name: "Takviyeli Saplı Plastik Çanta",
    category: "magaza",
    material: "HDPE Ekstra Güçlü Plastik",
    thickness: "95",
    pricePerUnit: 2.10,
    currency: "₺",
    moq: 10000,
    imageUrl: IMAGES.magazaBag,
    tags: ["Ağır Taşıma", "Takviyeli Sap", "Pürüzsüz Doku"],
    capacity: "Orta & Ağır Ciltler",
    description: "Taşıma kapasitesini maksimum düzeye ulaştıran özel takviye kaynaklı sap bölmesi ile kozmetik, tekstil ve perakende mağazalarının vazgeçilmezi."
  },
  {
    id: "prod-5",
    name: "Geri Dönüşümlü Balonlu Kargo Zarfı",
    category: "kargo",
    material: "LDPE Balonlu Naylon + Co-Ex Laminasyon",
    thickness: "140",
    pricePerUnit: 2.75,
    currency: "₺",
    moq: 5000,
    imageUrl: IMAGES.moq3DPreview,
    tags: ["Kırılabilir Ürün", "Korumalı Balon", "Hafiflik"],
    capacity: "Hassas Gönderiler",
    description: "Özellikle elektronik, aksesuar ve kırılgan yapıdaki butik siparişleriniz için iç yapısı hava kabarcıklı, dış yüzeyi neme karşı dayanıklı koruyucu zarf."
  },
  {
    id: "prod-6",
    name: "Kilitli (Doypack) Gıda & Kahve Torbası",
    category: "gida",
    material: "PET/ALU/PE Bariyer Laminasyon",
    thickness: "120",
    pricePerUnit: 4.20,
    currency: "₺",
    moq: 3000,
    imageUrl: IMAGES.adhesivePockets,
    tags: ["Aroma Korumalı", "Kilit Mekanizmalı", "U-Clip Açılış"],
    capacity: "Kahve & Kuru Gıda",
    description: "Oksijen ve nem bariyeri sağlayan çok katmanlı alüminyum laminasyonu ile gıda koruma standartlarına uygun dik duran zipli ambalaj çeşidi."
  }
];
