import React, { useState } from "react";
import Header from "./components/Header";
import HomeTab from "./components/HomeTab";
import CatalogTab from "./components/CatalogTab";
import AssistantTab from "./components/AssistantTab";
import { Product, QuoteSpec } from "./types";
import { X, Sparkles, ShoppingBag, Trash } from "lucide-react";
import { motion } from "motion/react";

export default function App() {
  const [currentTab, setTab] = useState<"home" | "catalog" | "assistant">("home");
  const [quotationList, setQuotationList] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeInitialPrompt, setActiveInitialPrompt] = useState<string | null>(null);

  React.useEffect(() => {
    const pathname = window.location.pathname;
    const searchParams = new URLSearchParams(window.location.search);
    if (pathname.includes("teklif.html") || searchParams.has("baski_durumu")) {
      const urun = searchParams.get("urun") || "";
      const malzeme = searchParams.get("malzeme") || "";
      const kalinlik = searchParams.get("kalinlik") || "";
      const baskiDurumu = searchParams.get("baski_durumu") || "Baskılı";
      
      let customPrompt = "";
      if (urun) {
        customPrompt = `${urun} için malzeme: ${malzeme}, kalınlık: ${kalinlik}. baski_durumu: ${baskiDurumu} detaylarına göre özel fiyat teklifi almak istiyorum.`;
      } else {
        customPrompt = `Yeni marka logolu poşet tasarımı ve teknik şartnamesi hazırlatmak istiyorum. baski_durumu: ${baskiDurumu}`;
      }
      setActiveInitialPrompt(customPrompt);
      setTab("assistant");
    }
  }, []);

  // Home search bar triggers prompt
  const handleAnalyzePromptFromHero = (prompt: string) => {
    setActiveInitialPrompt(prompt);
    setTab("assistant");
  };

  // Catalog customize button triggers prompt
  const handleCustomizeFromCatalog = (prompt: string) => {
    setActiveInitialPrompt(prompt);
    setTab("assistant");
  };

  const handleAddToQuotationList = (product: Product) => {
    setQuotationList(prev => {
      // Avoid raw duplicates
      if (prev.some(p => p.id === product.id)) return prev;
      return [...prev, product];
    });
  };

  const handleRemoveFromQuotationList = (prodId: string) => {
    setQuotationList(prev => prev.filter(p => p.id !== prodId));
  };

  const handleConsolidatedQuoteRequest = () => {
    setIsCartOpen(false);
    const itemNames = quotationList.map(p => p.name).join(", ");
    const consolidatedPrompt = `Seçtiğim şu ürün grubu için toplu bir teknik şartname ve fiyat teklifi oluşturur musunuz: ${itemNames}. Her birinin özellikleri ve toplu üretim süreçlerindeki avantajları nelerdir?`;
    handleCustomizeFromCatalog(consolidatedPrompt);
  };

  const handlePlaceOrder = (spec: QuoteSpec) => {
    console.log("Order placed for specification:", spec);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col justify-between selection:bg-indigo-600 selection:text-white" id="main-application-container">
      {/* Universal header navigation */}
      <Header
        currentTab={currentTab}
        setTab={setTab}
        quotationListCount={quotationList.length}
        onOpenQuotationList={() => setIsCartOpen(true)}
      />

      {/* Main interactive tabs layout switcher with fade entrance */}
      <main className="flex-grow">
        {currentTab === "home" && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <HomeTab
              onAnalyzePrompt={handleAnalyzePromptFromHero}
              setTab={setTab}
            />
          </motion.div>
        )}

        {currentTab === "catalog" && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <CatalogTab
              onAddToQuoteList={handleAddToQuotationList}
              onCustomizeWithAI={handleCustomizeFromCatalog}
              setTab={setTab}
            />
          </motion.div>
        )}

        {currentTab === "assistant" && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <AssistantTab
              initialPrompt={activeInitialPrompt}
              onClearInitialPrompt={() => setActiveInitialPrompt(null)}
              onPlaceOrder={handlePlaceOrder}
            />
          </motion.div>
        )}
      </main>

      {/* Cart Quotation List slide-out modal */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" id="quotation-bag-wrapper">
          {/* Backdrop overlay */}
          <div 
            className="absolute inset-0 bg-slate-950/45 backdrop-blur-xs transition-opacity" 
            onClick={() => setIsCartOpen(false)}
          />

          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col h-full border-l border-slate-100" id="quotation-bag-body">
              {/* Cart Header */}
              <div className="p-6 border-b border-slate-100 bg-slate-900 text-white flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <ShoppingBag className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-bold font-display text-sm uppercase tracking-wider">Teklif Sepeti Listesi</h3>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {quotationList.length === 0 ? (
                  <div className="text-center py-16 text-slate-400 space-y-3">
                    <ShoppingBag className="w-12 h-12 mx-auto text-slate-200" />
                    <p className="font-semibold text-sm">Teklif listeniz boş.</p>
                    <p className="text-xs text-slate-400">Ürün kataloğundan dilediğiniz modelleri sepetinize ekleyebilirsiniz.</p>
                  </div>
                ) : (
                  quotationList.map(item => (
                    <div key={item.id} className="flex items-center space-x-3 p-3.5 bg-slate-50 border border-slate-100 rounded-xl relative group">
                      <img 
                        src={item.imageUrl} 
                        alt={item.name} 
                        className="w-14 h-14 object-cover rounded-lg shrink-0 border border-slate-200"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 space-y-0.5">
                        <h5 className="text-[12px] font-bold text-slate-900 line-clamp-1">{item.name}</h5>
                        <div className="flex items-center space-x-2 text-[10px] text-slate-500 font-mono">
                          <span>{item.material}</span>
                          <span>•</span>
                          <span>MOQ: {item.moq.toLocaleString()} Adet</span>
                        </div>
                        <p className="text-xs font-extrabold text-indigo-600 font-mono">
                          {item.currency}{item.pricePerUnit.toFixed(2)} <span className="text-[9px] text-slate-400 font-normal">/ Adet</span>
                        </p>
                      </div>
                      <button
                        onClick={() => handleRemoveFromQuotationList(item.id)}
                        className="text-slate-400 hover:text-rose-500 p-1.5 rounded-lg hover:bg-white border border-transparent hover:border-slate-100 transition-all cursor-pointer shrink-0"
                        title="Sepetten Çıkar"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Cart Footer */}
              {quotationList.length > 0 && (
                <div className="p-6 border-t border-slate-100 bg-slate-50 space-y-4 shrink-0">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                    <span>Toplam Eklendi:</span>
                    <span>{quotationList.length} Model Ürün</span>
                  </div>

                  <button
                    onClick={handleConsolidatedQuoteRequest}
                    className="w-full bg-slate-950 hover:bg-indigo-600 text-white text-xs font-bold py-3 px-6 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-indigo-100/30"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                    <span>Seçilenler İçin AI Teklifi Al</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Action WhatsApp Support Badge - Positioned alt-sağ corner exactly as in the reference screenshot */}
      <div className="fixed bottom-6 right-6 z-[9999] flex flex-col items-center space-y-3" id="floating-support-container">
        {/* Soft greeting bubble next to the icon tooltipped - cursor interactive hover:opacity-0 to prevent blocking the content underneath */}
        <div className="hidden sm:block absolute right-16 bottom-2 whitespace-nowrap bg-white border border-slate-100 text-[11.5px] font-bold text-slate-700 py-1.5 px-3.5 rounded-full shadow-lg pointer-events-auto hover:opacity-0 transition-all duration-300 ease-in-out cursor-pointer select-none animate-bounce" title="Altındaki yazıları okumak için fareyle üzerine gelebilirsiniz">
          <span className="text-[#25D366]">●</span> Müşteri Destek Grubu
        </div>

        {/* WhatsApp Button Wrapper to align absolute under-glow waves */}
        <div className="relative">
          {/* Breathing soft glow halo */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-[#25D366]/40 blur-md animate-pulse pointer-events-none -z-10" />
          
          {/* Continuous expanding ripple wave ring */}
          <div className="absolute top-0 left-0 w-14 h-14 rounded-full bg-[#25D366]/50 animate-ping pointer-events-none -z-10" style={{ animationDuration: '2.5s' }} />
          
          <a 
            href="https://wa.me/905322153403" 
            target="_blank" 
            rel="noopener noreferrer" 
            id="whatsapp-fixed-trigger"
            className="w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-xl shadow-emerald-600/30 transition-transform duration-300 hover:scale-110 active:scale-95 cursor-pointer relative z-10"
            title="Bizimle WhatsApp Üzerinden İletişime Geçin"
          >
            {/* Inner Classic WhatsApp Logo in white */}
            <svg 
              className="w-7.5 h-7.5 fill-current" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M12.004 2C6.48 2 2 6.48 2 12C2 13.9 2.53 15.68 3.45 17.2L2 22L6.96 20.65C8.42 21.52 10.13 22 12.004 22C17.528 22 22.008 17.52 22.008 12C22.008 6.48 17.528 2 12.004 2ZM17.144 16.59C16.924 17.21 16.034 17.75 15.394 17.9C14.864 18.03 14.184 18.12 11.834 17.15C8.834 15.91 6.894 12.87 6.744 12.67C6.594 12.47 5.484 11 5.484 9.48C5.484 7.96 6.254 7.22 6.544 6.92C6.774 6.69 7.154 6.58 7.514 6.58C7.634 6.58 7.744 6.59 7.844 6.59C8.134 6.6 8.284 6.62 8.474 7.07C8.714 7.65 9.304 9.08 9.374 9.23C9.444 9.38 9.514 9.58 9.414 9.78C9.314 9.98 9.234 10.08 9.084 10.25C8.934 10.42 8.794 10.55 8.644 10.73C8.504 10.89 8.344 11.06 8.524 11.37C8.704 11.67 9.324 12.69 10.244 13.51C11.434 14.57 12.414 14.91 12.734 15.05C13.054 15.19 13.244 15.16 13.424 14.95C13.604 14.74 14.214 14.03 14.434 13.72C14.654 13.41 14.874 13.46 15.174 13.57C15.474 13.68 17.074 14.47 17.404 14.63C17.734 14.79 17.954 14.87 18.034 15.01C18.114 15.15 18.114 15.82 17.894 16.44L17.144 16.59Z"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
}
