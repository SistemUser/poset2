import { IMAGES } from "./constants";

export interface TaxonomyProduct {
  id: string;
  name: string;
  desc: string;
  categoryKey: "kargo_eticaret" | "plastik_poset" | "kagit_karton" | "bez_tela" | "koruyucu_endustriyel";
  categoryLabel: string;
  malzeme: string;
  specLabel?: string;
  specValue: string;
  baski: "Baskılı" | "Baskısız" | "Çok Renk" | "Tek Renk" | "En Az 1 Renk" | "CMYK (Çok Renk)";
  unitText: string;
  priceText: string;
  isPremiumPrice: boolean;
  badges: string[];
  imgUrl: string;
}

export const CATEGORIES = [
  { key: "kargo_eticaret", label: "E-Ticaret ve Kargo Ambalajları", count: 6 },
  { key: "plastik_poset", label: "Plastik Poşetler", count: 7 },
  { key: "kagit_karton", label: "Kağıt ve Karton Çantalar", count: 3 },
  { key: "bez_tela", label: "Bez ve Tela Çantalar", count: 2 },
  { key: "koruyucu_endustriyel", label: "Koruyucu ve Endüstriyel Ambalaj", count: 2 }
];

export const TAXONOMY_PRODUCTS: TaxonomyProduct[] = [
  // 1. E-TİCARET VE KARGO AMBALAJLARI
  {
    id: "tx-kargo-1",
    name: "Baskılı (Logolu) Kargo Poşetleri",
    desc: "Marka logolu, yüksek mukavemetli co-ex yapısıyla yırtılmaz e-ticaret kargo poşeti.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "LDPE (Co-Ex)",
    specValue: "70 Mikron",
    baski: "Baskılı",
    unitText: "Birim Fiyat (Minimum 10.000 Adet)",
    priceText: "₺1.45",
    isPremiumPrice: false,
    badges: ["Baskılı", "Çok Satan"],
    imgUrl: IMAGES.kargoBag
  },
  {
    id: "tx-kargo-2",
    name: "Cepli Kargo Poşetleri",
    desc: "Fatura ve irsaliye yerleşimi için kendinden yapışkanlı şeffaf arka cepli poşet.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "LDPE",
    specValue: "65 Mikron",
    baski: "Baskısız",
    unitText: "Birim Fiyat (Minimum 10.000 Adet)",
    priceText: "₺1.35",
    isPremiumPrice: false,
    badges: ["Cepli"],
    imgUrl: IMAGES.kargoBag
  },
  {
    id: "tx-kargo-3",
    name: "Standart (Baskısız) Kargo Poşetleri",
    desc: "Yüksek mukavemetli, siyah iç astarlı standart gri/opak kargo poşeti.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "LDPE (Co-Ex)",
    specValue: "50 Mikron",
    baski: "Baskısız",
    unitText: "Birim Fiyat (1000 Adet)",
    priceText: "₺1.25",
    isPremiumPrice: false,
    badges: ["Stokta"],
    imgUrl: IMAGES.kargoBag
  },
  {
    id: "tx-kargo-4",
    name: "Kağıt Kargo Poşetleri",
    desc: "Sürdürülebilir, geri dönüştürülebilir ve dayanıklı kraft kağıttan üretilmiş kargo ambalajı.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "Kraft Kağıt",
    specLabel: "Gramaj",
    specValue: "110 gr/m²",
    baski: "Baskısız",
    unitText: "Birim Fiyat (1000 Adet)",
    priceText: "₺2.80",
    isPremiumPrice: false,
    badges: ["Eko-Dostu"],
    imgUrl: IMAGES.kraftBag
  },
  {
    id: "tx-kargo-5",
    name: "Fatura Cebi ve İrsaliye Zarfları",
    desc: "Kolilerin ve paketlerin üzerine yapıştırılan şeffaf, yapışkanlı polietilen cep.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "Şeffaf PE",
    specValue: "40 Mikron",
    baski: "Baskısız",
    unitText: "Birim Fiyat (1000 Adet)",
    priceText: "₺0.45",
    isPremiumPrice: false,
    badges: ["Yapışkanlı"],
    imgUrl: IMAGES.adhesivePockets
  },
  {
    id: "tx-kargo-6",
    name: "Balonlu Kargo Zarfları",
    desc: "Dış yüzeyi parlak, iç yüzeyindeki hava kabarcıklı korumasıyla hassas butik gönderi zarfı.",
    categoryKey: "kargo_eticaret",
    categoryLabel: "E-Ticaret ve Kargo Ambalajları",
    malzeme: "PE Laminasyon / Patpat",
    specValue: "120 Mikron",
    baski: "Baskılı",
    unitText: "Birim Fiyat (Minimum 5000 Adet)",
    priceText: "₺2.75",
    isPremiumPrice: false,
    badges: ["Hassas", "Korumalı"],
    imgUrl: IMAGES.moq3DPreview
  },

  // 2. PLASTİK POŞETLER
  {
    id: "tx-plastik-1",
    name: "Mağaza Poşeti - El Geçme",
    desc: "Perakende, giyim ve butikleriniz için pürüzsüz parlak veya mat bitişli takviyeli el geçme poşet.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "LDPE",
    specValue: "70 Mikron",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 10.000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Butik", "Özel Üretim"],
    imgUrl: IMAGES.magazaBag
  },
  {
    id: "tx-plastik-2",
    name: "Mağaza Poşeti - Takviyeli",
    desc: "Ağır tekstil ürünleri ve ayakkabı kutuları için el geçme yerinden ekstra kaynak takviyeli.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "HDPE / MDPE",
    specValue: "85 Mikron",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 10.000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Takviyeli", "Ağır Taşıma"],
    imgUrl: IMAGES.magazaBag
  },
  {
    id: "tx-plastik-3",
    name: "Mağaza Poşeti - Yumuşak Saplı",
    desc: "Lüks mağaza deneyimi için gövdeden harici olarak kaynaklanmış şerit kulplu taşıma poşeti.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "LDPE Premium",
    specValue: "90 Mikron",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 10.500 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Lüks", "Saplı"],
    imgUrl: IMAGES.magazaBag
  },
  {
    id: "tx-plastik-4",
    name: "Market Poşetleri - Atlet",
    desc: "Market, eczane ve manavlar için yüksek taşıma mukavemetine sahip ekonomik hışır poşet.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "HDPE (Hışır)",
    specValue: "18 Mikron",
    baski: "Baskılı",
    unitText: "Birim Fiyat (Minimum 10.000 Adet)",
    priceText: "₺0.25",
    isPremiumPrice: false,
    badges: ["Hızlı Tüketim"],
    imgUrl: IMAGES.magazaBag
  },
  {
    id: "tx-plastik-5",
    name: "Kilitli & Fermuarlı Poşetler (Doypack vb.)",
    desc: "Gıdanın ve medikal ürünlerin tazeliğini ve hijyenini koruyan dik duran zipli kilit torba.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "PET + PE Bariyer",
    specValue: "120 Mikron",
    baski: "Baskılı",
    unitText: "Birim Fiyat (Minimum 5000 Adet)",
    priceText: "₺4.20",
    isPremiumPrice: false,
    badges: ["Zipli", "Gıdaya Uygun"],
    imgUrl: IMAGES.adhesivePockets
  },
  {
    id: "tx-plastik-6",
    name: "Jelatin & OPP Poşetler",
    desc: "Tekstil paketlemesinde kullanılan, kendinden yapışkanlı veya düz ultra parlak koruyucu naylon.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "OPP / PP",
    specValue: "30 Mikron",
    baski: "Baskısız",
    unitText: "Birim Fiyat (1000 Adet)",
    priceText: "₺0.60",
    isPremiumPrice: false,
    badges: ["Tekstil Paketi"],
    imgUrl: IMAGES.adhesivePockets
  },
  {
    id: "tx-plastik-7",
    name: "Biyobozunur (Doğada Çözünür) Poşetler",
    desc: "Mısır nişastası bazlı, çevreye zarar vermeden doğada %100 kompost olabilen ekolojik poşet.",
    categoryKey: "plastik_poset",
    categoryLabel: "Plastik Poşetler",
    malzeme: "Kompostlanabilir PLA",
    specValue: "45 Mikron",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 10.000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["%100 Yerli", "Kompost"],
    imgUrl: IMAGES.magazaBag
  },

  // 3. KAĞIT VE KARTON ÇANTALAR
  {
    id: "tx-kagit-1",
    name: "Kraft Çantalar",
    desc: "Doğal görünümlü kahverengi/beyaz burgu saplı kağıt çanta; paket servis, fırın ve mağazalar için ideal.",
    categoryKey: "kagit_karton",
    categoryLabel: "Kağıt ve Karton Çantalar",
    malzeme: "FSC Kraft Kağıt",
    specLabel: "Gramaj",
    specValue: "90 gr/m²",
    baski: "Baskılı",
    unitText: "Birim Fiyat (Minimum 5000 Adet)",
    priceText: "₺3.40",
    isPremiumPrice: false,
    badges: ["FSC Onaylı", "Burgu Saplı"],
    imgUrl: IMAGES.kraftBag
  },
  {
    id: "tx-kagit-2",
    name: "Lüks Karton Çantalar",
    desc: "Lüks segment butikler, kuyumcular ve kozmetik markaları için kalın kuşe karton ve ip saplı lüks çanta.",
    categoryKey: "kagit_karton",
    categoryLabel: "Kağıt ve Karton Çantalar",
    malzeme: "210gr Amerikan Bristol Karton",
    specLabel: "Gramaj",
    specValue: "210 gr/m²",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 2000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Premium", "Laminasyonlu"],
    imgUrl: IMAGES.kraftBag
  },
  {
    id: "tx-kagit-3",
    name: "Kese Kağıtları",
    desc: "Fırıncılık, unlu mamuller ve fast-food zincirleri için dipli/dipsiz neme dayanıklı şık kese kağıtları.",
    categoryKey: "kagit_karton",
    categoryLabel: "Kağıt ve Karton Çantalar",
    malzeme: "Sülfit Kağıt / Kraft",
    specLabel: "Gramaj",
    specValue: "40 gr/m²",
    baski: "Baskısız",
    unitText: "Birim Fiyat (1000 Adet)",
    priceText: "₺0.85",
    isPremiumPrice: false,
    badges: ["Gıda Dostu"],
    imgUrl: IMAGES.kraftBag
  },

  // 4. BEZ VE TELA ÇANTALAR
  {
    id: "tx-bez-1",
    name: "Nonwoven (Tela) Çantalar",
    desc: "Uzun ömürlü, çok kullanımlık (ultrasonik dikişli) ekonomik, dayanıklı ekolojik bez çanta.",
    categoryKey: "bez_tela",
    categoryLabel: "Bez ve Tela Çantalar",
    malzeme: "Tela Elyaf (Nonwoven)",
    specLabel: "Gramaj",
    specValue: "80 gr/m²",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 3000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Çok Kullanımlık", "Sürdürülebilir"],
    imgUrl: IMAGES.moq3DPreview
  },
  {
    id: "tx-bez-2",
    name: "Ham Bez (Pamuk) Çantalar",
    desc: "Doğal pamuklu ham bez kumaştan, uzun kollu, marka bilinirliğini sokaklara taşıyacak taşıma çantası.",
    categoryKey: "bez_tela",
    categoryLabel: "Bez ve Tela Çantalar",
    malzeme: "%100 Ham Pamuk",
    specValue: "140gr Kumaş",
    baski: "Baskılı",
    unitText: "Fiyat Alınız (Minimum 1000 Adet)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Kumaş", "Eko Premium"],
    imgUrl: IMAGES.moq3DPreview
  },

  // 5. KORUYUCU VE ENDÜSTRİYEL AMBALAJ
  {
    id: "tx-koruyucu-1",
    name: "Balonlu Patpat Naylonlar",
    desc: "Mobilya, cam ve kıymetli eşya taşımacılığında kırılmaları önleyen rulo balonlu koruyucu ambalaj.",
    categoryKey: "koruyucu_endustriyel",
    categoryLabel: "Koruyucu ve Endüstriyel Ambalaj",
    malzeme: "Çift Seviyeli LDPE",
    specValue: "120 Mikron",
    baski: "Baskısız",
    unitText: "Fiyat Alınız (Rulo)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Darbe Emici", "Koruyucu"],
    imgUrl: IMAGES.moq3DPreview
  },
  {
    id: "tx-koruyucu-2",
    name: "Şrink Filmler (P.E, POF, PVC)",
    desc: "Ürünlerinizi ısı yardımıyla sıkıca sararak toz, kir ve nemden koruyan endüstriyel şrink rulo film.",
    categoryKey: "koruyucu_endustriyel",
    categoryLabel: "Koruyucu ve Endüstriyel Ambalaj",
    malzeme: "Poliolefin (POF) / PE",
    specValue: "15 Mikron",
    baski: "Baskısız",
    unitText: "Birim Fiyat (Rulo)",
    priceText: "Fiyat Alınız",
    isPremiumPrice: true,
    badges: ["Endüstriyel", "Isıl İşlem"],
    imgUrl: IMAGES.adhesivePockets
  }
];

export const getProductByName = (name: string): TaxonomyProduct | undefined => {
  const clean = name.toLowerCase();
  return TAXONOMY_PRODUCTS.find(p => p.name.toLowerCase().includes(clean) || clean.includes(p.name.toLowerCase()));
};
